import sys, os, zetric

PATH = os.path.join(os.path.split(os.path.split(sys.argv[0])[0])[0], 'assets')
zetric.gui.GRAPHIC_PATH = PATH

def read(name):
    return zetric.util.readFileData(os.path.join(PATH, name))

def getFile(name, mode):
    return open(os.path.join(PATH, name), mode)

svg_parser = zetric.svg.SvgParser()
svg_cache = {}

def readSvg(name):
    name = name.replace('/', '\\')
    return svg_cache[name]

def _readSvg(name):
    return zetric.svg.SvgRoot.readSvg(svg_parser.parse(read(name)), svg_parser)

for root, dirs, files in os.walk(PATH):
    path = root[len(PATH)+1:]
    for name in files:
        if name.endswith('.svg'):
            place = os.path.join(path, name)
            svg_cache[place] = _readSvg(place)