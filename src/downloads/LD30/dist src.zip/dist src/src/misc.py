import pygame, zetric, abc, resource

class LevelParser(zetric.xml.Parser):
    def __init__(self, cls):
        zetric.xml.Parser.__init__(self, cls)
        self.objs = {}

class LevelClass():
    def __init__(self):
        pass
    
    def levelInit(self, element, parser):
        if 'id' in element.attrs:
            parser.objs[element.attrs['id']] = self
    
    @staticmethod
    @abc.abstractmethod
    def readLevel(element, parser, parent=None):
        pass
    
    @abc.abstractmethod
    def writeLevel(self, stream):
        pass
    
    @staticmethod
    def getDefaultAttrs():
        return {}

class Tile():
    WIDTH =  25
    HEIGHT = 25
    SIZE = (WIDTH, HEIGHT)
    TILES = {}
    
    empty = None
    filled = None
    spawn = None
    exit = None
    
    def __init__(self, ID, graphic, solid):
        self.ID = ID
        Tile.TILES[self.ID] = self
        root = resource.readSvg('tile/%s.svg' %graphic)
        image = zetric.visual.Image((-1, -1), (root.width, root.height))
        root.render(image)
        self.image = pygame.transform.scale(image, Tile.SIZE)
        self.solid = solid

Tile.empty = Tile(1, 'empty', False)
Tile.filled = Tile(2, 'filled', True)
Tile.spawn = Tile(3, 'spawn', False)
Tile.exit = Tile(4, 'exit', False)

SCREEN_SIZE = (1100, 500)
SCREEN_WIDTH, SCREEN_HEIGHT = SCREEN_SIZE

class EventRenderLayer(zetric.visual.RenderEvent):
    ID = zetric.event.uniqueEventID()
    def __init__(self, image):
        self.image = image

class EventTickGame(zetric.event.Event):
    ID = zetric.event.uniqueEventID()
    def __init__(self):
        zetric.event.Event.__init__(self, None)

class EventUpdate(zetric.event.Event):
    ID = zetric.event.uniqueEventID()
    def __init__(self):
        zetric.event.Event.__init__(self, None)

class EventShadowInit(zetric.event.Event):
    ID = zetric.event.uniqueEventID()
    def __init__(self):
        zetric.event.Event.__init__(self, None)