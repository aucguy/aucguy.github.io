import abc

#TODO support comments
#TODO support html and xml crazy headers

class SvgClass():
    @staticmethod
    @abc.abstractmethod
    def readSvg(element, parser):
        if 'class' in element.attrs:
            element.attrs = interface.util.joinDict(parser.getStyle(element.attrs['class']), element.attrs)
        if 'style' in element.attrs:
            element.attrs = interface.util.joinDict(parseAttrs(element.attrs['style']), element.attrs)
        if element.parent != None:
            element.attrs = interface.util.joinDict(element.attrs, element.parent.attrs)
        element.attrs = interface.util.joinDict(element.attrs, parser.getClass(element.name).getDefaultAttrs())
        if isinstance(element.attrs, dict):
            element.attrs = interface.xml.AttributeHolder(element.attrs)
    
    @staticmethod
    @abc.abstractmethod
    def getDefaultAttrs():
        return {}
    
class HtmlClass():
    def htmlInit(self, element, parser):
        if 'id' in element.attrs:
            parser.objs[element.attrs['id']] = self
    
    @staticmethod
    @abc.abstractmethod
    def readHtml(element, parser):
        if 'class' in element.attrs:
            element.attrs = interface.util.joinDict(parser.getStyle(element.attrs['class']), element.attrs)
        if 'style' in element.attrs:
            element.attrs = interface.util.joinDict(parseAttrs(element.attrs['style']), element.attrs)
        if element.parent != None:
            element.attrs = interface.util.joinDict(element.attrs, element.parent.attrs)
        element.attrs = interface.util.joinDict(element.attrs, parser.getClass(element.name).getDefaultAttrs())
        element.attrs = interface.util.joinDict(element.attrs, HtmlClass.getDefaultAttrs())
        if isinstance(element.attrs, dict):
            element.attrs = interface.xml.AttributeHolder(element.attrs)
    
    @staticmethod
    @abc.abstractmethod
    def getDefaultAttrs():
        return {'position': 'static', 'left': '0px', 'right': '0px'}

class AttributeHolder():
    def __init__(self, properties=None, default={}):
        if properties == None:
            properties = {}
        if default == None:
            default = {}
        self.properties = interface.util.joinDict(properties, default)
    
    def getAttr(self, name):
        if name in self.properties:
            return self.properties[name]
        else:
            raise KeyError, "no attribute named '%s'" %name
    
    def setAttr(self, name, value):
        self.properties[name] = value
        
    def __getitem__(self, name):
        return self.getAttr(name)
    
    def __setitem__(self, name, value):
        self.setAttr(name, value)
    
    def __contains__(self, name):
        return name in self.properties
    
    def __iter__(self):
        for i in self.properties:
            yield i

class Token():
    def __init__(self, line, column):
        self.line = line
        self.column = column

class TokenBasic(Token):
    def __init__(self, text, line, column, kind):
        Token.__init__(self, line, column)
        self.text = text
        self.kind = kind

class BasicEnum():
    WORD = None
    NUMBER = None
    SYMBOL = None
    WHITESPACE = None
    LITERAL = None
    KEYWORD = None

BasicEnum.WORD = BasicEnum()
BasicEnum.NUMBER = BasicEnum()
BasicEnum.SYMBOL = BasicEnum()
BasicEnum.WHITESPACE = BasicEnum()
BasicEnum.LITERAL = BasicEnum()
BasicEnum.KEYWORD = BasicEnum()
        
class BasicType():
    TYPE_WORD = None
    TYPE_NUMBER = None
    TYPE_SYMBOL = None
    TYPE_WHITESPACE = None
    TYPE_LITERAL = None
    TYPE_KEYWORD = None
    
    def __init__(self, name, start, more="", enum=None):
        self.name = name
        self.start = start
        
        if self.start == None:
            self.more = None
        else:
            self.more = start+more
        self.enum = enum
        
    @staticmethod
    def getType(char):
        for i in [BasicType.TYPE_WORD, BasicType.TYPE_NUMBER, BasicType.TYPE_SYMBOL, BasicType.TYPE_WHITESPACE]:
            if char in i.start:
                return i
        return None

BasicType.TYPE_WORD = BasicType("WORD", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_", "012346789:-", enum=BasicEnum.WORD)
BasicType.TYPE_NUMBER = BasicType("NUMBER", "0123456789", enum=BasicEnum.NUMBER)
BasicType.TYPE_SYMBOL = BasicType("SYMBOL", "`~!@#$%^&*()=+[{]}\\|;',<.>/?-", enum=BasicEnum.SYMBOL)
BasicType.TYPE_WHITESPACE = BasicType("WHITESPACE", " \t\n\r", enum=BasicEnum.WHITESPACE)
BasicType.TYPE_LITERAL = BasicType("LITERAL", None, enum=BasicEnum.LITERAL)
BasicType.TYPE_KEYWORD = BasicType("KEYWORD", None, enum=BasicEnum.KEYWORD)

class TokenGroup(Token):
    def __init__(self, children):
        Token.__init__(self, children[0].line, children[0].line)
        self.children = children
        
    def __iter__(self):
        for token in self.children:
            yield token

class Stream():
    def __init__(self, tokens):
        self.tokens = iter(tokens)
        self.queue = []
        self.has_left = True
    
    def expectText(self, text):
        token = self.next()
        if token.text != text:
            raise SyntaxError, "expected token with %s text @ %s" %(text, str((token.line, token.column)))
        return token
        
    def expectType(self, kind):
        token = self.next()
        if token.kind != kind:
            raise SyntaxError, "expected token with %s type @ %s" %(kind.name, str((token.line, token.column)))
        return token
    
    def expectInstance(self, cl):
        token = self.next()
        if not isinstance(token, cl):
            raise SyntaxError, "expected token of %s instance @ %s" %(cl.__name__, str((token.line, token.column)))
        return token
    
    def advanceIfText(self, text):
        token = self.next()
        if token.text != text:
            self.queue.append(token)
        return token
    
    def advanceIfType(self, kind):
        token = self.next()
        if not isinstance(token, TokenBasic) or token.kind != kind:
            self.queue.append(token)
        return token
    
    def assertText(self, text):
        token = self.next()
        if token.text != text:
            raise AssertionError, "expected token with %s text @ %s" %(text, str((token.line, token.column)))
        return token
    
    def assertType(self, kind):
        token = self.next()
        if token.kind != kind:
            raise AssertionError, "expected token with %s type @ %s" %(kind.name, str((token.line, token.column)))
        return token
    
    def left(self):
        if not self.has_left:
            return False
        else:
            try:
                token = self.next()
                self.queue.append(token)
                return True
            except StopIteration:
                return False
    
    def empty(self):
        return not self.left()
    
    def next(self, whitespace=False):
        token = None
        while token == None or (isinstance(token, TokenBasic) and token.kind.enum == BasicEnum.WHITESPACE):
            if len(self.queue) != 0:
                token = self.queue.pop(-1)
            elif not self.has_left:
                raise StopIteration, "no more tokens remaining"
            else:
                try:
                    token = self.tokens.next()
                except StopIteration:
                    self.has_left = False
                    raise StopIteration, "no more tokens remaining"
            if whitespace:
                break
        return token
    
    def nextOld(self):
        if len(self.queue) != 0:
            token = self.queue.pop(-1)
            return token
        elif not self.has_left:
            raise StopIteration, "no more tokens remaining"
        else:
            try:
                return self.tokens.next()
            except StopIteration:
                self.has_left = False
                raise StopIteration, "no more tokens remaining"
    
    def nextNoAdvance(self, whitespace=False):
        token = self.next(whitespace)
        self.queue.append(token)
        return token

class TagPos():
    pass

TagPos.START = TagPos()
TagPos.END = TagPos()
TagPos.MARK = TagPos()

class TokenTag(Token):
    def __init__(self, group):
        Token.__init__(self, group.line, group.column)
        
        assert group.children[0].text == '<'
        assert group.children[-1].text == '>'
        self.pos = TagPos.START
        if group.children[1].text == '/':
            self.pos = TagPos.END
        if group.children[-2].text == '/':
            if self.pos == TagPos.END:
                raise SyntaxError, "tag cannot be an end and a mark @ %s" %str((group.line, group.column))
            else:
                self.pos = TagPos.MARK
        
        stream = Stream(group)
        stream.assertText('<')
        
        stream.advanceIfText('/')
        self.name = stream.expectType(BasicType.TYPE_WORD).text
        self.attrs = {}
        
        while stream.left():
            if stream.nextNoAdvance().text == '>' or stream.nextNoAdvance().text == '/':
                break
            key = stream.expectType(BasicType.TYPE_WORD)
            stream.expectText("=")
            value = stream.expectType(BasicType.TYPE_LITERAL)
            self.attrs[key.text] = value.text    
        
        stream.advanceIfText('/')
        stream.assertText('>')
        
class TokenText(Token):
    def __init__(self, group):
        Token.__init__(self, group.line, group.column)
        self.text = ""
        for i in group:
            self.text += i.text        

class TokenNumber(Token):
    def __init__(self, group):
        Token.__init__(self, group.line, group.column)
        s = ""
        for token in group.children:
            s += token.text
        self.num = float(s)
        self.text = s

class Element():
    def __init__(self, name, attrs=None, children=None):
        self.name = name
        if attrs == None:
            attrs = AttributeHolder()
        if children == None:
            children = []
        self.attrs = attrs
        self.children = []
        for i in children:
            self.addChild(i)
        self.parent = None
    
    def getAttr(self, name):
        return self.attrs.getAttr(name)
    
    def addChild(self, child):
        self.children.append(child)
        if child.parent != None:
            raise TypeError, "child may not have multiple parents"
        child.parent = self

class ElementRoot(Element):
    def __init__(self):
        Element.__init__(self, "$root")

class ElementText(Element):
    def __init__(self, text):
        Element.__init__(self, "$text")
        self.text = text

class Parser():
    def __init__(self, classes=None):
        if classes == None:
            classes = {}
        self.classes = classes
        self.words_exclude_nums = True
        self.elem_cl = Element
        self.basictype_cl = BasicType
    
    def registerClass(self, name, cl):
        self.classes[name] = cl
    
    def registerClasses(self, classes):
        for key in classes:
            self.registerClass(key, classes[key])
    
    def getClass(self, name):
        return self.classes[str(name)]
    
    def hasClass(self, name):
        return str(name) in self.classes
    
    def parse(self, code):
        return self.parse_elements(code)
       
    def parse_elements(self, code):
        stack = interface.util.Stack()
        stack.push(ElementRoot())
        for tag in self.parse_tags(code):
            if isinstance(tag, TokenTag):
                if tag.pos == TagPos.START:
                    try:
                        cl = self.getClass(tag.name)
                    except KeyError:
                        cl = None
                    
                    if cl != None:
                        default = cl.getDefaultAttrs()
                    else:
                        default = {}
                    element = self.elem_cl(tag.name, AttributeHolder(tag.attrs, default))
                    stack.peek().addChild(element)
                    stack.push(element)
                elif tag.pos == TagPos.MARK:
                    try:
                        cl = self.getClass(tag.name)
                    except KeyError:
                        cl = None
                    
                    element = self.elem_cl(tag.name, AttributeHolder(tag.attrs))
                    stack.peek().addChild(element)
                elif tag.pos == TagPos.END:
                    if stack.peek().name != tag.name:
                        raise SyntaxError, "tag with name of %s trys to close tag with name of %s @ %s" %(tag.name, stack.peek().name, str((tag.line, tag.column)))
                    else:
                        stack.pop()
                else:
                    raise AssertionError, "invalid tag pos"
            elif isinstance(tag, TokenText):
                if tag.text.replace('\n', '').replace('\r', '').replace('\t', '').replace(' ', '') != '':
                    element = ElementText(tag.text)
                    stack.peek().addChild(element)
            else:
                raise AssertionError, "invalid object yielded by Parser.parse_tags"
        
        if not isinstance(stack.peek(), ElementRoot):
            raise SyntaxError, "Unclosed element"
        return stack.pop()
    
    def parse_tags(self, code):
        group = []
        in_tag = False
        for token in self.parse_symbols(code, ['<', '>', '=', '/', '\\', '?', '<!--', '-->', '<?', '?>', '<!']):
            if token.text == '<':
                if in_tag:
                    raise SyntaxError, "cannot have '<' within tag @ %s" %str((token.line, token.column))
                else:
                    in_tag = True
                    if len(group) != 0:
                        yield TokenText(TokenGroup(group))
                    group = [token]
            elif token.text == '>':
                if in_tag:
                    in_tag = False
                    group.append(token)
                    if len(group) != 0:
                        yield TokenTag(TokenGroup(group))
                    group = []
            else:
                group.append(token)
    
    def parse_symbols(self, code, legal):
        legal = list(legal)
        legal.sort()
        legal.reverse()
        
        for token in self.parse_basic(code):
            if token.text in legal:
                yield token
            elif token.kind != self.basictype_cl.TYPE_SYMBOL:
                yield token
            else:
                line = token.line
                column = token.column
                text = token.text
                
                while text != '':
                    bad = True
                    for i in legal:
                        if text.startswith(i):
                            bad = False
                            text = text.lstrip(i)
                            yield TokenBasic(i, column, line, self.basictype_cl.TYPE_SYMBOL)
                            column += len(i)
                            break
                    if bad:
                        yield TokenBasic(text, column, line, self.basictype_cl.TYPE_SYMBOL)
                        break
    
    def parse_symbolsOld(self, code, splits):
        translate = {}
        for split in splits:
            s = ""
            for i in split:
                s += i
            translate[s] = split
        
        for token in self.parse_basic(code):
            if token.text in translate:
                line = token.line
                column = token.column
                for i in translate[token.text]:
                    yield(TokenBasic(i, line, column, self.basictype_cl.getType(i[0])))
                    for k in i:
                        if i == '\n':
                            line += 1
                            column = 0
                        elif i == '\t':
                            column += 4
                        else:
                            column += 1
            else:
                yield token
    
    def parse_numbers(self, code, splits):
        parts = []
        pos = 0 #0-negative, 1-first num, 2-decimal place, 3-second num
        for token in self.parse_symbols(code, splits):    
            if pos == 0 and token.text == '-': #must be first
                parts.append(token)
                pos = 1
            elif (pos == 0 or pos == 1) and token.kind == self.basictype_cl.TYPE_NUMBER: #can be first or second
                parts.append(token)
                pos = 2
            elif pos == 2 and token.text == '.': #must be third
                parts.append(token)
                pos = 3
            elif pos == 3 and token.kind == self.basictype_cl.TYPE_NUMBER:
                parts.append(token)
                pos = 4
            else: #failure or done
                if len(parts) != 0:
                    yield TokenNumber(TokenGroup(parts))
                    parts = []
                pos = 0
                
                if token.text == '-': #if the current token that made failure is part of the next decimals sequence
                    parts.append(token)
                    pos = 1
                elif token.kind == self.basictype_cl.TYPE_NUMBER:
                    parts.append(token)
                    pos = 2
                else: #the token is just something else
                    yield token
                    
        if len(parts) != 0: #might have leftovers that weren't ended because they were at the end
            yield TokenNumber(TokenGroup(parts))
        
        
    def parse_basic(self, code):
        current_type = None
        current_text = ""
        current_line = 1
        current_column = 1
        start_line = 1
        start_column = 1
        slash = False
        
        for i in code:
            if i == '\n':
                current_line += 1
                current_column = 1
            elif i == '\t':
                current_column += 4
            else:
                current_column += 1
                
            if current_type == None:
                current_type = self.basictype_cl.getType(i)
                
            if slash:
                assert current_type == self.basictype_cl.TYPE_LITERAL
                slash = False
                current_text += {"n":"\n", "t":"\t", "b":"\b", "r":"\r", "\"":"\"", "\\":"\\"}[i] #TODO check that the character is in the dictionary
            elif current_type == self.basictype_cl.TYPE_LITERAL:
                if i == '"':
                    yield TokenBasic(current_text, start_line, start_column, current_type)
                    start_line = current_line
                    start_column = current_column
                    current_type = None
                    current_text = ""
                elif i == '\\':
                    slash = True
                else:
                    current_text += i
            else:
                if self.words_exclude_nums and current_type == self.basictype_cl.TYPE_WORD and i in self.basictype_cl.TYPE_NUMBER.more:
                    b = False
                else:
                    if i in current_type.more:
                        b = True
                    else:
                        b = False
                
                if b:
                    current_text += i
                elif i == '"':
                    yield TokenBasic(current_text, start_line, start_column, current_type)
                    start_line = current_line
                    start_column = current_column
                    current_type = self.basictype_cl.TYPE_LITERAL
                    current_text = ""
                else:
                    yield TokenBasic(current_text, start_line, start_column, current_type)
                    start_line = current_line
                    start_column = current_column
                    current_type = self.basictype_cl.getType(i)
                    current_text = ""
                    current_text += i
        
        if current_type == self.basictype_cl.TYPE_LITERAL:
            raise SyntaxError, "open quotes"
        elif current_type != None:
            yield TokenBasic(current_text, start_line, start_column, current_type)
            
    def debug_tags(self, code):
        for token in self.parse_tags(code):
            text = ""
            if isinstance(token, TokenTag):
                text += "Tag "
                if token.pos == TagPos.START:
                    text += "start"
                elif token.pos == TagPos.END:
                    text += "end"
                elif token.pos == TagPos.MARK:
                    text += "mark"
                else:
                    text += "null"
                text += ": "
                text += token.name + ", " + str(token.attrs)
            elif isinstance(token, TokenText):
                text += "Text: " + token.text
            else:
                text += "Null"
            
    def debug_elements(self, code, element=None, indent=0):
        if element == None:
            element = self.parse_elements(code)
        
        print("\t"*indent+"%s, %s" %(element.name, str(element.attrs)))
        for i in element.children:
            self.debug_elements(code, i, indent+1)

def parseAttrs(s, default={}, pair=':', split=';'):
    parts = s.split(split)
    d = {}
    for part in parts:
        if len(part) > 0:
            stuff = part.split(pair)
            if len(stuff) != 2:
                raise SyntaxError, "incorrect number of pair sequence(s)"
            d[stuff[0]] = stuff[1]
    return AttributeHolder(d, default)

def parseColor(s):
    if s.startswith('#'):
        return(int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16))
    elif s.lower() == 'none':
        return (0,0,0)
    else:
        raise TypeError, "Unknown color format: %s" %s

import __init__ as interface