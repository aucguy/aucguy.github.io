import pygame, abc, math
import __init__ as interface

def init():
	pass

def loadImage(path):
	return Image((0,0), pygame.image.load(path))

class RenderEvent(interface.event.Event):
	def __init__(self):
		interface.event.Event.__init__(self, None)

class EventRenderScreen(RenderEvent):
	"""event used for rendering the screen"""
	ID = interface.event.uniqueEventID()
	
	def __init__(self, image):
		RenderEvent.__init__(self)
		self.image = image
	
class Renderable():
	def __init__(self, pos):
		self.renderRect = interface.util.Rect(pos, (-1,-1))
	
	@abc.abstractmethod
	def render(self, image):
		pass

def draw_with_alpha(func, surface, color, *args, **kargs):
	if len(color) == 3 or color[3] == 255:
		func(surface, color, *args, **kargs)
	else:
				#help from Mike Lawrence
		#https://www.mail-archive.com/pygame-users@seul.org/msg04323.html
		#accessed February 22, 2014
		
		if tuple(color)[0:3] == (0,0,0):
			key = (255,0,0)
		else:
			key = (0,0,0)
		
		size = surface.get_rect().size
		sur1 = pygame.surface.Surface(size)
		func(sur1, color[0:3], *args, **kargs)
		sur2 = pygame.surface.Surface(size, pygame.SRCCOLORKEY)
		sur2.blit(sur1, (0,0))
		sur2.set_colorkey(key)
		sur2.set_alpha(color[3])
		sur3 = pygame.surface.Surface(size, pygame.SRCALPHA)
		sur3.blit(sur2, (0,0))
		surface.blit(sur3, (0,0))

class Sprite(Renderable):
	"""used for rendering stuff for a tick."""
	def __init__(self, rect):
		self.rect = rect

class Image(Sprite, pygame.surface.Surface):
	"""Just like a surface"""

	def __init__(self, pos, size_or_surface, flags=pygame.SRCALPHA):
		if isinstance(size_or_surface, (pygame.surface.Surface, Image)):
			size = size_or_surface.get_rect().size
			surface = size_or_surface
		elif isinstance(size_or_surface, (tuple, list)):
			size = size_or_surface
			surface = None
		else:
			raise TypeError, "%s is not a valid size or surface" %str(size_or_surface)
		
		Sprite.__init__(self, interface.util.Rect(pos, size))
		pygame.surface.Surface.__init__(self, size, flags)
		if surface != None:
			self.blit(surface.convert_alpha(), (0,0))
		self.pos = pos

	def getRect(self):
		return self.get_rect()

	def render(self, image):
		image.blit(self, self.pos)
	
	def blit(self, image, location):
		pygame.surface.Surface.blit(self, image, location)
	
class Font(pygame.font.Font):
	def __init__(self, name=None, size=12):
		pygame.font.Font.__init__(self, name, size)

	def render(self, image, pos, text, color=(0,0,0,255), background=(255,255,255,0)):
		#help from Mike Lawrence
		#https://www.mail-archive.com/pygame-users@seul.org/msg04323.html
		#accessed February 22, 2014
		
		size = self.size(text)
		if background == (0,0,0,0) or background == [0,0,0,0]:
			back_no_alpha = (255, 255, 255, 0)
		else:
			back_no_alpha = background[0:3]
		
		if len(color) == 3:
			color = list(color)
			color.append(255)
		if len(background) == 3:
			background = list(background)
			background.append(0)
		
		sur1 = pygame.font.Font.render(self, text, False, color[0:3], back_no_alpha)
		sur2 = pygame.surface.Surface(size, pygame.SRCCOLORKEY)
		sur2.blit(sur1, (0,0))
		sur2.set_colorkey(back_no_alpha)
		sur2.set_alpha(color[3])
		sur3 = pygame.surface.Surface(size, pygame.SRCALPHA)
		sur3.fill(background)
		sur3.blit(sur2, (0,0))
		image.blit(sur3, pos)

class Text(Sprite, interface.xml.SvgClass):
	def __init__(self, pos, font, text, color=None, background=None):
		Sprite.__init__(self, pos)
		if color == None:
			color = (0,0,0,255)
		if len(color) == 3:
			color = list(color)
			color.append(255)
		
		if background == None:
			background = (255,255,255,0)
		if len(background) == 3:
			background = list(background)
			background.append(255)
		
		self.text = text
		self.font = font
		self.color = color
		self.background = background
	
	def render(self, image):
		self.font.render(image, self.rect.topleft, self.text, self.color, self.background)
	
	@staticmethod
	def readSvg(element, parser):
		interface.xml.SvgClass.readSvg(element, parser)
		common = interface.svg.CommonAttrs(element.attrs)
		family = element.attrs['font-family']
		
		size = interface.svg.parseDist(element.attrs['font-size'])
		line_height = float(element.attrs['line-height'].rstrip('%')) / 100
		size *= line_height
		size = int(round(size))
		
		data = (family, size)
		x = int(float(element.attrs['x']))
		y = int(float(element.attrs['y']))-size/2
		
		if parser.hasFont(data):
			font = parser.getFont(data)
		else:
			font = Font(None, size)
			parser.setFont(data, font)
		
		text = ""
		for child in element.children:
			if isinstance(child, interface.xml.ElementText):
				text += child.text
			if child.name == 'tspan':
				for i in child.children:
					if isinstance(i, interface.xml.ElementText):
						text += i.text
		text = text.replace("\n", "")
		text = text.replace("\t", "    ")
		
		if common.stroke[3] == 0:
			color = common.fill
		else:
			color = common.stroke
		return Text(interface.util.Rect((x,y), font.size(text)), font, text, color)
	
	@staticmethod
	def getDefaultAttrs():
		return {'fill':'#000000', 'stroke':'#000000', 'stroke-opacity':'1.0', 'stroke-width':'1', \
			'fill-opacity':'0.0', 'font-family':'Arial', 'font-size':'12', 'line-height':'100%'} #TODO make sure these defaults are the standards

class VisualRect(Sprite, interface.util.Rect, interface.xml.SvgClass):
	def __init__(self, rect, background, outline=None, line_width=0):
		Sprite.__init__(self, rect)
		if outline == None:
			outline = (0,0,0)
		interface.util.Rect.__init__(self, rect.topleft, rect.size)
		self.background = background
		self.outline = outline
		self.line_width = line_width
	
	@staticmethod
	def readSvg(element, parser):
		#TODO make sure this follows the specifications
		#TODO allow blank stuff
		interface.xml.SvgClass.readSvg(element, parser)
		common = interface.svg.CommonAttrs(element.attrs)
		x = int(float(element.attrs['x']))
		y = int(float(element.attrs['y']))
		width = int(float(element.attrs['width']))
		height = int(float(element.attrs['height']))
		
		return VisualRect(interface.util.Rect((x, y), (width, height)), common.fill, common.stroke, common.width)
	
	@staticmethod
	def getDefaultAttrs():
		return {'fill':'#000000', 'stroke':'#000000', 'stroke-opacity':'1.0', 'fill-opacity':'1.0', 'stroke-width':'1'} #TODO make sure these defaults are the standards
	
	def render(self, image):
		pygame.draw.rect(image, self.background, self)
		pygame.draw.lines(image, self.outline, True, (self.topleft, self.topright, self.bottomright, self.bottomleft), self.line_width)

class Team(Sprite, interface.xml.SvgClass):
	"""like a group, just for sprites instead of actors"""
	def __init__(self, sprites=None):
		if sprites == None:
			sprites = []
		self.sprites = sprites
	
	@staticmethod
	def readSvg(element, parser):
		interface.xml.SvgClass.readSvg(element, parser)
		instance = Team()
		for child in element.children:
			if child.name != '$text':
				obj = parser.getClass(child.name).readSvg(child, parser)
				if 'id' in child.attrs:
					parser.setElementById(obj, child.attrs['id'])
				if isinstance(obj, Sprite):
					instance.addSprite(obj)
		return instance
	
	@staticmethod
	def getDefaultAttrs():
		return {}
	
	def addSprite(self, sprite):
		if sprite not in self.sprites:
			self.sprites.append(sprite)
	
	def removeSprite(self, sprite):
		if sprite in self.sprites:
			self.sprites.remove(sprite)
			
	def addSprites(self, sprites):
		for sprite in sprites:
			self.addSprite(sprite)
			
	def removeSprites(self, sprites):
		for sprite in sprites:
			self.removeSprite(sprite)
	
	def render(self, image):
		for sprite in self.sprites:
			sprite.render(image)

class Line(Sprite):
	def __init__(self, pos1, pos2, color, width=1):
		self.pos1 = pos1
		self.pos2 = pos2
		self.color = color
		self.width = width
	
	def render(self, image):
		pygame.draw.line(image, self.color, self.pos1, self.pos2, self.width)

class Polygon(Sprite):
	def __init__(self, points, stroke, fill, width=1, closed=False):
		self.points = points
		self.stroke = stroke
		self.fill = fill
		self.width = width
		self.closed = closed
	
	def render(self, image):
		pygame.draw.lines(image, self.stroke, self.closed, self.points, self.width)
		draw_with_alpha(pygame.draw.polygon, image, self.fill, self.points)

class ArcEllipse(Sprite):
	"""credits to 'Mr. McLogan's Math Channel' video, '10.3 How to find the center, foci and vertices of an ellipse' at 'https://www.youtube.com/watch?v=lmBcss4NJuI' and
	wikipedia's ellipse article at 'http://en.wikipedia.org/wiki/Ellipse' for the math. Also 'http://stackoverflow.com/questions/197649/how-to-calculate-center-of-an-ellipse-by-two-points-and-radius-sizes'
	and various places on the internet"""
	
	def __init__(self, start, stop, center, dim, rot, fill, stroke, width=1):
		self.start = int(round(start))
		self.stop = int(round(stop))
		self.h = center[0]
		self.k = center[1]
		self.a = dim[0]
		self.b = dim[1]
		self.rotation = rot
		self.fill = fill
		self.stroke = stroke
		self.line_width = width
	
	def render(self, image):
		"""thank you pygame source"""
		
		points = []
		
		for i in xrange(self.start, self.stop+1):
			r = math.radians(i)
			x1 = math.cos(r)*self.a
			y1 = math.sin(r)*self.b
			dist = math.hypot(x1, y1)
			angle = math.atan2(y1,x1)+self.rotation
			x2 = self.h+math.cos(angle)*dist
			y2 = self.k+math.sin(angle)*dist
			points.append((int(x2), int(y2)))
		
		pygame.draw.polygon(image, self.fill, points)
		pygame.draw.lines(image, self.stroke, False, points, self.line_width)

class ArcBezier(Sprite):
	"""a bezier sprite"""
	def __init__(self, points, stroke, fill, width=1, steps=50):
		self.x, self.y = interface.util.unzip(points)
		self.stroke = stroke
		self.fill = fill
		self.width = width
		self.steps = steps
		
		self.update()
	
	def render(self, image):
		draw_with_alpha(pygame.draw.polygon, image, self.fill, self.data)
		pygame.draw.lines(image, self.stroke, False, self.data, self.width)
		
	def at(self, t, fn):
		
		n = len(self.x)-1
		if 0.9999999999999999 < t < 1.000000000000001:
			return (self.x[n], self.y[n])
		
		u = 1-t
		sx = 0
		sy = 0
		numerator = fn * u**n
		change = t/u
		denominator = fn
		# (math.factorial(i)*math.factorial(n-i))
		
		#first time the denominator is a special case
		sx += (numerator / denominator) * self.x[0]
		sy += (numerator / denominator) * self.y[0]
		numerator *= change
		denominator /= n
		
		for i in xrange(1, n):
			denominator *= i
			num = numerator / denominator
			
			sx += num * self.x[i]
			sy += num * self.y[i]
		
			numerator *= change
			denominator /= (n-i)
		
		#last time the denominator is a special case
		denominator *= n
		sx += (numerator / denominator) * self.x[n]
		sy += (numerator / denominator) * self.y[n]

		return (int(sx), int(sy))
	
	def update(self):
		self.data = []
		fn = math.factorial(len(self.x)-1)
		STEPS = 1000
		incr = 1.0/STEPS
		t = 0
		for i in xrange(STEPS):
			t += incr
			self.data.append(self.at(t, fn))