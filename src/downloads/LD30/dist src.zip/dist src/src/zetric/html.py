import __init__ as interface

class HtmlParser(interface.xml.Parser):
    def __init__(self, rect, cls=None):
        if cls == None:
            cls = HTML_CLASSES
        interface.xml.Parser.__init__(self, cls)
        self.layoutManager = LayoutManager(rect)
        self.objs = {}

class LayoutManager():
    def __init__(self, rect):
        self.rect = rect
        self.reset()
    
    def reset(self):
        self.current_x, self.current_y = self.rect.topleft
        self.row_height = 0
    
    def putElement(self, size):
        if self.current_x + size[0] > self.rect.left + self.rect.width:
            self.current_x = self.rect.left
            self.current_y += self.row_height
        if size[1] > self.row_height:
            self.row_height = size[1]
        x = self.current_x
        y = self.current_y
        self.current_x += size[0]
        return interface.util.Rect((x, y), size)

class HtmlRoot(interface.actor.Group, interface.xml.HtmlClass):
    @staticmethod
    def readHtml(element, parser):
        interface.xml.HtmlClass.readHtml(element, parser)
        instance = HtmlRoot()
        
        for child in element.children:
            if parser.hasClass(child.name):
                instance.add(parser.getClass(child.name).readHtml(child, parser))
        instance.objs = parser.objs
        return instance
    
    def getElementById(self, ID):
        return self.objs[ID]

class HtmlBody(interface.actor.Group, interface.xml.HtmlClass):
    @staticmethod
    def readHtml(element, parser):
        interface.xml.HtmlClass.readHtml(element, parser);
        instance = HtmlBody()
        
        for child in element.children:
            if parser.hasClass(child.name):
                obj = parser.getClass(child.name).readHtml(child, parser)
                instance.add(obj)
        return instance

class HtmlText(interface.actor.Actor, interface.visual.Text):
    def __init__(self, pos, font, text, color=None, background=None):
        interface.actor.Actor.__init__(self)
        interface.visual.Text.__init__(self, pos, font, text, color, background)
    
    @interface.actor.script(interface.visual.EventRenderScreen.ID, 'MAIN_RENDER')
    def draw(self, event):
        self.render(event.image)
        
    @staticmethod
    def readHtml(element, parser):
        interface.xml.HtmlClass.readHtml(element, parser)
        font = interface.visual.Font(None, int(element.attrs['font-size']))       
        text = element.text.replace('\t', '').replace('\n', '').replace('\r', '')         
        pos = parser.layoutManager.putElement(font.size(text))
        color = interface.xml.parseColor(element.attrs['color'])
        background = interface.xml.parseColor(element.attrs['background'])
        instance = HtmlText(pos, font, text, color, background)
        return instance
        
    @staticmethod
    def getDefaultAttrs():
        return {'font-size': '12', 'color': '#000000', 'background': '#FFFFFF'}

HTML_CLASSES = {'$root': HtmlRoot, 'html': HtmlRoot, 'body': HtmlBody, 'button': interface.gui.Button, '$text': HtmlText, 'div': interface.actor.Group}