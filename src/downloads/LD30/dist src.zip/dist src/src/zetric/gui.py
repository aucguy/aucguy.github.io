import pygame, os
import __init__ as interface

GRAPHIC_PATH = None

TEXT = pygame.SCRAP_TEXT

def init_screen():
    pygame.scrap.init()
    
def setClipboard(kind, data):
    pygame.scrap.put(kind, data)

def getClipboard(kind):
    return pygame.scrap.get(kind)

class EventMenuChange(interface.event.Event):
    ID = interface.event.uniqueEventID()

    def __init__(self, menu):
        interface.event.Event.__init__(self, None)
        self.menu = menu

class MenuManager(interface.actor.Actor):
    def __init__(self, start):
        interface.actor.Actor.__init__(self)
        self.current = start
        interface.core.Engine.getInstance().actors.add(self.current)

    @interface.actor.script(EventMenuChange.ID, 'MAIN_EVENT')
    def changeMenu(self, event):
        interface.core.Engine.getInstance().actors.remove(self.current)
        interface.core.Engine.getInstance().actors.add(event.menu)
        self.current = event.menu

class EventClick(interface.event.Event):
    ID_DOWN = interface.event.uniqueEventID()
    ID_UP = interface.event.uniqueEventID()
    
    def __init__(self, ID, collide):
        interface.event.Event.__init__(self, None)
        self.ID = ID
        self.collide = collide

class EventButtonActivate(interface.event.Event):
    ID = interface.event.uniqueEventID()

    def __init__(self):
        interface.event.Event.__init__(self, None)

class Button(interface.actor.Actor, interface.visual.Renderable, interface.xml.HtmlClass):
    def __init__(self, pos, text, graphic):
        interface.actor.Actor.__init__(self)
        interface.visual.Renderable.__init__(self, pos)
        
        self.init_images(text, graphic)
        self.image = self.unpressed
        self.state = False
        self.renderRect.size = self.image.get_rect().size
    
    @interface.actor.script(interface.event.EventMouseDown.ID_LEFT, 'MAIN_EVENT')
    def buttonDown(self, event):
        if self.renderRect.collidepoint(event.pos):
            self.event_queue.broadcast(EventClick(EventClick.ID_DOWN, True))

    @interface.actor.script(interface.event.EventMouseUp.ID_LEFT, 'MAIN_EVENT')
    def buttonUp(self, event):
        self.event_queue.broadcast(EventClick(EventClick.ID_UP, self.renderRect.collidepoint(event.pos)))
    
    @interface.actor.script(EventClick.ID_DOWN, 'internal')
    def onClick(self, event):
        self.state = True
        self.image = self.pressed

    @interface.actor.script(EventClick.ID_UP, 'internal')
    def onUnClick(self, event):
        if event.collide and self.state:
            self.event_queue.broadcast(EventButtonActivate())
        self.state = False
        self.image = self.unpressed
        
    @interface.actor.script(interface.visual.EventRenderScreen.ID, 'MAIN_RENDER')
    def render(self, event):
        event.image.blit(self.image, self.renderRect.topleft)
    
    def init_images(self, text, graphic):
        self.unpressed = self.loadSvg(text, False, graphic)
        self.pressed = self.loadSvg(text, True, graphic)
        self.image = self.unpressed
        
    def loadSvg(self, text, darkened, path):
        parser = interface.svg.SvgParser()
        graphic = interface.svg.SvgRoot.readSvg(parser.parse(interface.util.readFileData(path)), parser)
        if darkened:
            for sprite in graphic.getElementById('outline').sprites:
                if isinstance(sprite, interface.visual.Polygon):
                    sprite.fill = (128,128,128,255)
                    
        graphic.getElementById('splitter').sprites[0].color = (0,0,0,0)
        
        text_elem = graphic.getElementById('text')
        org_text = text_elem.text
        text_elem.text = text
        split = graphic.getElementById('splitter').sprites[0].pos1[0]
        shift = text_elem.font.size(text_elem.text)[0]-text_elem.font.size(org_text)[0]
        
        self.shift_split(graphic, split, shift)
        
        image = interface.visual.Image(self.renderRect.topleft, (graphic.width+shift, graphic.height))
        graphic.render(image)
        return image
    
    def shift_split(self, sprite, split, shift):
        if isinstance(sprite, interface.visual.Team):
            for i in sprite.sprites:
                self.shift_split(i, split, shift)
        elif isinstance(sprite, interface.visual.Polygon):
            for i, point in enumerate(sprite.points):
                if point[0] > split:
                    sprite.points[i] = (point[0]+shift, point[1])
        elif isinstance(sprite, interface.visual.Line):
            if sprite.pos1[0] > split:
                sprite.pos1 = (sprite.pos1[0]+shift, sprite.pos1[1])
            if sprite.pos2[0] > split:
                sprite.pos2 = (sprite.pos2[0]+shift, sprite.pos2[1])
        elif isinstance(sprite, interface.visual.Text):
            if sprite.rect.left > split:
                sprite.rect.left += shift
        elif isinstance(sprite, interface.visual.VisualRect):
            if sprite.left > split:
                sprite.left += shift
            if sprite.left+sprite.width > split:
                sprite.width += shift
        else:
            raise Exception, "type %s is unsupported" %sprite.__class__
    
    @staticmethod
    def readHtml(element, parser):
        interface.xml.HtmlClass.readHtml(element, parser)
        
        text = ""
        for child in element.children:
            if isinstance(child, interface.xml.ElementText):
                text += child.text
        
        position = element.attrs['position']
        if position == 'static':
            element.attrs['left'] = '0px'
            element.attrs['top'] = '0px'
            position = 'relative'
                
        if position == 'absolute':
            pos = (interface.svg.parseDist(element.attrs['left']), interface.svg.parseDist(element.attrs['top']))
        elif position == 'relative':
            pos = (0,0) #temporary value since if the position is relative we need to create the instance to figure out what the real pos is
        else:
            raise SyntaxError, 'position of type %s is unsupported' %position
        
        if 'graphic' in element.attrs and GRAPHIC_PATH != None:
            graphic = os.path.join(GRAPHIC_PATH, element.attrs['graphic'])
        else:
            graphic = 'conf/button.svg'
        instance = Button(pos, text, graphic) #TODO put path into resources
        interface.xml.HtmlClass.htmlInit(instance, element, parser)
        
        if position == 'relative':
            instance.renderRect.topleft = parser.layoutManager.putElement(instance.renderRect.size).topleft
        return instance

class MenuSwitchButton(Button):
    def __init__(self, pos, text, portal):
        Button.__init__(self, pos, text, r"C:\Users\Owner\Documents\fun\python\tic-tac-toe\versions\3.1\Tests\files\button.svg")
        self.portal = portal

    @interface.actor.script(EventButtonActivate.ID, 'internal')
    def activate(self, event):
        interface.core.Engine.getInstance().getEventQueue().broadcast(EventMenuChange(self.portal))

class MenuPortal(interface.actor.Group):
    def __init__(self, cl, args=(), kargs={}):
        interface.actor.Group.__init__(self)
        self.cl = cl
        self.args = args
        self.kargs = kargs
    
    def onAdded(self, parent):
        self.add(self.cl(*self.args, **self.kargs))
        interface.actor.Group.onAdded(self, parent)