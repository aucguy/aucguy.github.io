import pygame, sys, copy
import __init__ as interface

def init():
	pass

MAIN_EVENT_QUEUE_ID = 'MAIN_EVENT'
MAIN_RENDER_QUEUE_ID = 'MAIN_RENDER'
eventStream = interface.event.EventStream()
renderStream = interface.event.EventStream()

def close():
	pygame.quit()

class Manager(interface.actor.Actor):
	def __init__(self):
		interface.actor.Actor.__init__(self)
	
	@interface.actor.script(interface.event.EventQuit.ID, MAIN_EVENT_QUEUE_ID)
	def quit(self, event):
		pygame.quit()
		sys.exit()

class MainGroup(interface.actor.Group):
	def add(self, *actors):
		orginal = copy.copy(self.actors)
		interface.actor.Group.add(self, *actors)
		for actor in actors:
			if actor not in orginal:
				actor.onAdded(self)
				
	def remove(self, *actors):
		orginal = copy.copy(self.actors)
		interface.actor.Group.remove(self, *actors)
		for actor in actors:
			if actor in orginal:
				actor.onRemoved(self)

class Engine():
	the_instance = None
	def __init__(self, size):
		self.screen = pygame.display.set_mode(size, pygame.SRCALPHA) #credits to Mike Lawrence for this fix

		self.event_queue = interface.event.EventQueue(MAIN_EVENT_QUEUE_ID)
		self.render_queue = interface.event.EventQueue(MAIN_RENDER_QUEUE_ID, stream=renderStream)

		self.actors = MainGroup()
		self.manager = Manager()
		self.actors.add(self.manager)
		
		interface.gui.init_screen()
		
	@staticmethod
	def getInstance():
		return the_instance

	@staticmethod
	def createInstance(screen_size):
		global the_instance
		the_instance = Engine(screen_size)

	def getEventQueue(self):
		return self.event_queue

	def handleEvents(self):
		self.event_queue.convertRaw()
		eventStream.handleEvents()

	def render(self, background=(0,0,0)):
		self.screen.fill(background)
		image = interface.visual.Image((0,0), self.screen.get_rect().size)
		self.render_queue.broadcast(interface.visual.EventRenderScreen(image))
		renderStream.handleEvents()
		self.screen.blit(image, (0,0))
		pygame.display.update()
	
	def quitOnError(self):
		pygame.quit()