import pygame, profile, util, xml, event, visual, svg, actor, gui, html, core

def init():
	global pygame, profile, util, xml, event, visual, svg, actor, gui, html, core
	
	pygame.init()
	pygame.font.init()
	
	core.init()
	actor.init()
	event.init()
	visual.init()