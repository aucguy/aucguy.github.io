import pygame, Queue, time, abc, traceback, sys
import __init__ as interface

key_string = None
keyboard_pairs = None #ie '{' and '[' or '5' and '%' or 'a' and 'A'
key_identifiers = None

def init():
	global key_string, keyboard_pairs, key_identifiers
	
	key_identifiers = {}
	for key in dir(pygame):
		if key.startswith('K_'):
			value = eval("pygame.%s" %key)
			name = key.lstrip('K_').upper()
			key_identifiers[value] = name

	key_string = interface.util.loadConf("key_string")
	
	EventKeyDown.clinit();
	EventKeyUp.clinit();
	EventKeyHeld.clinit();
	
	keyboard_pairs = interface.util.loadConf("keyboard_pairs")
	
next_event_ID = 0
def uniqueEventID():
	global next_event_ID
	r = next_event_ID
	next_event_ID += 1
	return r

key_presses = {}

def isKeyPressed(keys):
	for key in keys:
		if key in key_presses and key_presses[key]:
			return True
	return False

class ScriptError(Exception):
	pass

class Event():
	def __init__(self, raw):
		self.trace = None

class EventQuit(Event):
	ID = uniqueEventID()

class EventKey(Event):	
	def __init__(self, raw, key=None):
		Event.__init__(self, None)
		self.timePressed = time.time()
		
		if key == None:
			key = raw.key
		identifier = key_identifiers[key]
		self.ID = eval("self.ID_%s" %identifier)
		
		self.name = key_string[identifier]
		
		if self.name in keyboard_pairs and interface.util.nand(pygame.key.get_mods() & pygame.KMOD_SHIFT == 0, pygame.key.get_mods() & pygame.KMOD_CAPS):
			self.name = keyboard_pairs[self.name]
		
		if len(self.name) == 1:
			self.char = self.name
		else:
			self.char = ''
	
	@staticmethod
	@abc.abstractmethod
	def getID(name):
		pass
		
class EventKeyDown(EventKey):
	@staticmethod
	def clinit():
		for key in key_identifiers:
			event_id = uniqueEventID()
			exec("EventKeyDown.ID_%s = %i" %(key_identifiers[key], event_id))
	
	def __init__(self, raw):
		EventKey.__init__(self, raw)
		
	@staticmethod
	def getID(name):
		return eval("EventKeyDown.ID_%s" %name.upper())

class EventKeyUp(EventKey):
	@staticmethod
	def clinit():
		for key in key_identifiers:
			event_id = uniqueEventID()
			exec("EventKeyUp.ID_%s = %i" %(key_identifiers[key], event_id))
	
	def __init__(self, raw):
		EventKey.__init__(self, raw)
		
	@staticmethod
	def getID(name):
		return eval("EventKeyUp.ID_%s" %name.upper())

class EventKeyHeld(EventKey):
	@staticmethod
	def clinit():
		for key in key_identifiers:
			event_id = uniqueEventID()
			exec("EventKeyHeld.ID_%s = %i" %(key_identifiers[key], event_id))
	
	def __init__(self, raw_ID):
		EventKey.__init__(self, None, raw_ID)
		
	@staticmethod
	def getID(name):
		return eval("EventKeyHeld.ID_%s" %name.upper())

class EventMouse(Event):
	pass

class EventMouseDown(EventMouse):
	ID_LEFT = uniqueEventID()
	ID_MIDDLE = uniqueEventID()
	ID_RIGHT = uniqueEventID()
	button_bindings = {1: ID_LEFT, 2: ID_MIDDLE, 3: ID_RIGHT}

	def __init__(self, raw):
		EventMouse.__init__(self, raw)
		self.pos = raw.pos
		self.button = raw.button
		self.ID = self.button_bindings[self.button]

class EventMouseUp(EventMouse):
	ID_LEFT = uniqueEventID()
	ID_MIDDLE = uniqueEventID()
	ID_RIGHT = uniqueEventID()
	button_bindings = {1: ID_LEFT, 2: ID_MIDDLE, 3: ID_RIGHT}

	def __init__(self, raw):
		EventMouse.__init__(self, raw)
		self.pos = raw.pos
		self.button = raw.button
		self.ID = self.button_bindings[self.button]

class EventMouseHeld(EventMouse):
	ID_LEFT = uniqueEventID()
	ID_MIDDLE = uniqueEventID()
	ID_RIGHT = uniqueEventID()
	button_bindings = {0: ID_LEFT, 1: ID_MIDDLE, 2: ID_RIGHT}

	def __init__(self, button):
		EventMouse.__init__(self, None)
		self.pos = pygame.mouse.get_pos()
		self.button = button
		self.ID = self.button_bindings[self.button]	

convert_bind = 	{
				pygame.QUIT:				EventQuit,
				pygame.KEYDOWN:				EventKeyDown,
				pygame.KEYUP:				EventKeyUp,
				pygame.MOUSEBUTTONDOWN:		EventMouseDown,
				pygame.MOUSEBUTTONUP:		EventMouseUp
				}

class Broadcasted_Event():
	def __init__(self, queue, event):
		self.queue = queue
		self.event = event

	def handleEvent(self):
		self.queue.handleEvent(self.event)

class EventStream():
	def __init__(self):
		self.broadcasted = Queue.Queue()
		
	def handleEvents(self, limit=None):
		for broadcasted in interface.util.iterQueue(self.broadcasted, limit):
			broadcasted.handleEvent()

class EventQueue():
	queues = {}
	
	def __init__(self, ID, parents=(), stream=None):
		if stream == None:
			stream = interface.core.eventStream
		
		if not isinstance(parents, (list, tuple)):
			print(parents)
			raise TypeError, "parents arguement must be of type list or tuple"	
		
		self.ID = ID
		self.queues[ID] = self
		for queue_ID in parents:
			self.getQueue(queue_ID).addEventQueue(self)
		self.scripts = {}
		self.event_queues = []
		self.stream = stream

	@staticmethod
	def getQueue(ID):
		return EventQueue.queues[ID]
	
	def getScripts(self):
		return self.scripts

	def addScript(self, event_ID, script):
		if event_ID not in self.scripts:
			self.scripts[event_ID] = [script]
		elif script not in self.scripts[event_ID]:
			self.scripts[event_ID].append(script)

	def removeScript(self, event_ID, script):
		if event_ID in self.scripts and script in self.scripts[event_ID]:
			self.scripts[event_ID].remove(script)
	
	def getEventQueues(self):
		return self.event_queues

	def addEventQueue(self, child):
		if child not in self.event_queues:
			self.event_queues.append(child)

	def removeEventQueue(self, child):
		if child in self.event_queues:
			self.event_queues.remove(child)

	def broadcast(self, event):
		self.stream.broadcasted.put(Broadcasted_Event(self, event))
		event.trace = traceback.extract_stack()
		event.trace = event.trace[:len(event.trace)-1]

	def __iter__(self, limit=None):
		i = 0
		while True:
			if self.queue.empty():
				break
			yield self.nextEvent()
			if self.queue.empty:
				break
			i += 1
			if limit != None and i > limit:
				break
				
	def handleEvent(self, event):
		for queue in self.getEventQueues():
			queue.handleEvent(event)

		if event.ID in self.scripts:
			for script in self.scripts[event.ID]:
				try:
					script(event)
				except SystemExit:
					raise SystemExit
				except:
					sys.stderr.write("Error while running script\n")
					sys.stderr.write("event traceback:\n")
					sys.stderr.write(''.join(traceback.format_list(event.trace)))
					sys.stderr.write("\nscript traceback:\n")
					traceback.print_exc()
					raise ScriptError
	
	def get_raw(self):
		raws = []
		for event in pygame.event.get():
			raws.append(event)
		return tuple(raws)

	def convertRaw(self, raws=None):
		if raws == None:
			raws = self.get_raw()
	
		for raw in raws:
			if raw.type in convert_bind:
				event_class = convert_bind[raw.type]
				instance = event_class(raw)
				self.broadcast(instance)
		
		self.convertNewBaseEvents()
	
	def convertNewBaseEvents(self):
		self.convertKeyHolds()
		self.convertMouseHolds()

	def convertKeyHolds(self):
		global key_presses
		key_presses = {}
		for index, held in enumerate(pygame.key.get_pressed()):
			if held and index != 300: #numpad key
				event = EventKeyHeld(index)
				self.broadcast(event)
			if index in key_identifiers:
				key_presses[key_string[key_identifiers[index]]] = held
	
	def convertMouseHolds(self):
		for index, held in enumerate(pygame.mouse.get_pressed()):
			if held:
				event = EventMouseHeld(index)
				self.broadcast(event)