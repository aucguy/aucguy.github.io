import math #TODO get off numpy dependcy for pyjsdl and pyj2d
import __init__ as interface

class CommonAttrs():
    def __init__(self, attrs):
        self.fill = interface.util.joinLists(interface.xml.parseColor(attrs['fill']), [int(float(attrs['fill-opacity'])*255)])
        if attrs['fill'] == 'none':
            self.fill[3] = 0
        self.stroke = interface.util.joinLists(interface.xml.parseColor(attrs['stroke']), [int(float(attrs['stroke-opacity'])*255)])
        if attrs['stroke'] == 'none':
            self.stroke[3] = 0
        self.width = parseDist(attrs['stroke-width'])

class CssBasicType(interface.xml.BasicType):
    @staticmethod
    def getType(char):
        for i in [CssBasicType.TYPE_WORD, CssBasicType.TYPE_NUMBER, CssBasicType.TYPE_SYMBOL, CssBasicType.TYPE_WHITESPACE]:
            if char in i.start:
                return i
        return None
    
CssBasicType.TYPE_WORD = CssBasicType("WORD", "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_#", "012346789-", enum=interface.xml.BasicEnum.WORD)
CssBasicType.TYPE_NUMBER = CssBasicType("NUMBER", "0123456789", enum=interface.xml.BasicEnum.NUMBER)
CssBasicType.TYPE_SYMBOL = CssBasicType("SYMBOL", "`~!@$%^&*()=+[{]}\\|:;',<.>/?-", enum=interface.xml.BasicEnum.SYMBOL)
CssBasicType.TYPE_WHITESPACE = CssBasicType("WHITESPACE", " \t\n\r", enum=interface.xml.BasicEnum.WHITESPACE)
CssBasicType.TYPE_LITERAL = CssBasicType("LITERAL", None, enum=interface.xml.BasicEnum.LITERAL)
CssBasicType.TYPE_KEYWORD = CssBasicType("KEYWORD", None, enum=interface.xml.BasicEnum.KEYWORD)

class SvgElement(interface.xml.Element):
    pass

class SvgParser(interface.xml.Parser):
    def __init__(self):
        interface.xml.Parser.__init__(self, SVG_CLASSES)
        self.elem_cl = SvgElement
        self.styles = {} #name to AttributeHolder
        self.fonts = {} #Tuple to Font
        self.objs = {}
    
    def getStyle(self, name):
        return self.styles[name]
    
    def setStyle(self, name, style):
        self.styles[name] = style
    
    def getFont(self, name):
        return self.fonts[name]
    
    def setFont(self, name, font):
        self.fonts[name] = font
    
    def hasFont(self, name):
        return name in self.fonts
    
    def getElementById(self, ID):
        return self.objs[ID]
    
    def setElementById(self, obj, ID):
        self.objs[ID] = obj
    
    def hasElementById(self, ID):
        return ID in self.objs

class CssParser(interface.xml.Parser):
    def __init__(self):
        interface.xml.Parser.__init__(self)
        self.basictype_cl = CssBasicType
        self.words_exclude_nums = False

class SvgRoot(interface.visual.Team, interface.xml.SvgClass):
    def __init__(self):
        interface.visual.Team.__init__(self)
        self.width = None
        self.height = None
        self.objs = {}
    
    def getElementById(self, ID):
        return self.objs[ID]
    
    @staticmethod
    def readSvg(element, parser):
        #TODO xmlns metadata and def stuff
        interface.xml.SvgClass.readSvg(element, parser)
        instance = SvgRoot()
        
        try:
            instance.width = round(float(element.attrs["width"]))
            instance.height = round(float(element.attrs["height"]))
        except KeyError:
            pass
        
        for child in element.children:
            try:
                cl = parser.getClass(child.name)
            except KeyError:
                continue
            c = cl.readSvg(child, parser)
            if isinstance(c, interface.visual.Sprite):
                instance.addSprite(c)
            
            if isinstance(c, SvgRoot):
                instance.width = c.width
                instance.height = c.height
                
        instance.objs = parser.objs
        return instance

class Style(interface.xml.SvgClass):
    @staticmethod
    def readSvg(element, parser):
        if len(element.children) == 0:
            return None
        else:
            s = ""
            for child in element.children:
                s += child.text
            stream = interface.xml.Stream(CssParser().parse_numbers(s, {}))
            
            while stream.left():
                cl = stream.expectType(CssBasicType.TYPE_WORD).text
                attrs = interface.xml.AttributeHolder()
                stream.expectText('{')
                while stream.nextNoAdvance().text != '}':
                    key = stream.expectType(CssBasicType.TYPE_WORD).text
                    stream.expectText(':')
                    token = stream.next()
                    if isinstance(token, interface.xml.TokenNumber):
                        value = token.num
                    elif isinstance(token, interface.xml.TokenBasic) and token.kind == CssBasicType.TYPE_WORD:
                        value = token.text
                    attrs[key] = value
                    stream.advanceIfText(';')
                    if stream.nextNoAdvance().text == '}':
                        break
                stream.expectText('}')
                parser.setStyle(cl, attrs)

class SvgDefs(interface.xml.SvgClass):
    @staticmethod
    def readSvg(element, parser):
        for child in element.children:
            try:
                cl = parser.getClass(child.name)
            except KeyError:
                continue
            cl.readSvg(child, parser)

class Path(interface.visual.Team, interface.xml.SvgClass):
    @staticmethod
    def readSvg(element, parser):
        #TODO implement end caps
        interface.xml.SvgClass.readSvg(element, parser)
        instance = Path()
        parser = interface.xml.Parser()
        parser.words_exclude_nums = True
        stream = interface.xml.Stream(parser.parse_numbers(element.attrs['d'], (',','-','.')))
        common = CommonAttrs(element.attrs)
        
        command = None
        absolute = False
        x = None
        y = None
        last = None
        move = None
        
        while stream.left():
            cmd = stream.advanceIfType(interface.xml.BasicType.TYPE_WORD)
            if cmd != None and isinstance(cmd, interface.xml.TokenBasic) and cmd.kind == interface.xml.BasicType.TYPE_WORD:
                command = cmd.text.upper()
                absolute = cmd.text.upper() == cmd.text
                cmd = None
            
            if command == 'M': #moveto
                arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                stream.advanceIfText(',')
                arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                if x == None or absolute:
                    x = arg_x
                    y = arg_y
                else:
                    x += arg_x
                    y += arg_y
                del arg_x, arg_y
                command = 'L'
                
                last = None
                move = (x,y)
            elif command == 'L': #lineto
                points = [(x, y)]
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    if absolute:
                        if x == None:
                            raise SyntaxError, "first command may not be lineto('L')"
                        x = arg_x
                        y = arg_y
                    else:
                        x += arg_x
                        y += arg_y
                    points.append((x, y))
                
                if len(points) < 2:
                    pass
                elif len(points) == 2:
                    instance.addSprite(interface.visual.Line(points[0], points[1], common.stroke, common.width))
                else:
                    instance.addSprite(interface.visual.Polygon(points, common.stroke, common.fill, common.width))
                arg_x = None # in case there were no arguements
                arg_y = None
                del arg_x, arg_y, points
                last = None
            elif command == 'A': #elliptic arc
                data = []
                previous = None
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    rx = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    ry = stream.expectInstance(interface.xml.TokenNumber).num
                    rot = stream.expectInstance(interface.xml.TokenNumber).num
                    large_arc = stream.expectInstance(interface.xml.TokenNumber).num
                    sweep = stream.expectInstance(interface.xml.TokenNumber).num
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    org_x = x
                    org_y = y
                    
                    if absolute:
                        if x == None:
                            raise SyntaxError, "first command may not be ellipticalarc('A')"
                        x = arg_x
                        y = arg_y
                    else:
                        x += arg_x
                        y += arg_y
                    
                    cx, cy = Path.getCenter(org_x, org_y, x, y, large_arc, sweep, rx, ry, rot)
                    start_angle = Path.getAngle(cx, cy, org_x, org_y)
                    stop_angle = Path.getAngle(cx, cy, x, y)
                    
                    if start_angle < 0:
                        start_angle += 360
                    if stop_angle < 0:
                        stop_angle += 360
                        
                    if previous == (x,y):
                        start_angle += 180
                        stop_angle += 180
                    
                    if large_arc:
                        tmp = start_angle
                        start_angle = stop_angle
                        stop_angle = tmp
                        del tmp
                    
                    previous = (org_x,org_y)
                    data.append(interface.visual.ArcEllipse(min(start_angle, stop_angle), max(start_angle, stop_angle), (cx, cy), (rx, ry), rot, common.fill, common.stroke, common.width))
                    del arg_x, arg_y
                
                instance.addSprite(interface.visual.Team(data))
                del data, previous
                last = None
            elif command == 'C': #cubic bezier curve
                points = [(x,y)]
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    x1 = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    y1 = stream.expectInstance(interface.xml.TokenNumber).num
                    x2 = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    y2 = stream.expectInstance(interface.xml.TokenNumber).num
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    if absolute:
                        x = arg_x
                        y = arg_y
                    else:
                        x1 += x
                        y1 += y
                        x2 += x
                        y2 += y
                        x += arg_x
                        y += arg_y
                    points.append((x1,y1))
                    points.append((x2,y2))
                    points.append((x,y))
                    last = (x2,y2)
                instance.addSprite(interface.visual.ArcBezier(points, common.stroke, common.fill, common.width))
            elif command == 'S': #shorthand cubic bezier curve
                points = [(x,y)]
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    x2 = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    y2 = stream.expectInstance(interface.xml.TokenNumber).num
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    if last == None:
                        x1 = x
                        y1 = y
                    else:
                        x1 = -(x-last[0]) + x
                        y1 = (y-last[1]) + y
                    
                    if absolute:
                        x = arg_x
                        y = arg_y
                    else:
                        x2 += x
                        y2 += y
                        x += arg_x
                        y += arg_y
                    points.append((x1, y1))
                    points.append((x2,y2))
                    points.append((x,y))
                    last = (x2, y2)
                instance.addSprite(interface.visual.ArcBezier(points, common.stroke, common.fill, common.width))
                del points
            elif command == 'Q': #quadratic bezier curve
                points = [(x,y)]
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    x1 = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    y1 = stream.expectInstance(interface.xml.TokenNumber).num
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    if absolute:
                        x = arg_x
                        y = arg_y
                    else:
                        x1 += x
                        y1 += y
                        x += arg_x
                        y += arg_y
                    points.append((x1,y1))
                    points.append((x,y))
                    last = (x1,y1)
                instance.addSprite(interface.visual.ArcBezier(points, common.stroke, common.fill, common.width))
            elif command == 'T': #shorthand quadratic bezier curve
                points = [(x,y)]
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    stream.advanceIfText(',')
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    
                    if last == None:
                        x1 = x
                        y1 = y
                    else:
                        x1 = (x-last[0]) + x
                        y1 = (y-last[1]) + y
                    
                    if absolute:
                        x = arg_x
                        y = arg_y
                    else:
                        x += arg_x
                        y += arg_y
                    points.append((x1, y1))
                    points.append((x,y))
                    last = (x1, y1)
                instance.addSprite(interface.visual.ArcBezier(points, common.stroke, common.fill, common.width))
                del points, arg_x, arg_y
            elif command == 'H': #horizontal line to
                n = x
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    arg_x = stream.expectInstance(interface.xml.TokenNumber).num
                    if absolute:
                        n = arg_x
                    else:
                        n += arg_x
                instance.addSprite(interface.visual.Line((x,y), (n,y), common.stroke, common.width))
                x = n
                del n
                last = None
            elif command == 'V': #vertical line to
                n = y
                while stream.left() and isinstance(stream.nextNoAdvance(), interface.xml.TokenNumber):
                    arg_y = stream.expectInstance(interface.xml.TokenNumber).num
                    if absolute:
                        n = arg_y
                    else:
                        n += arg_y
                instance.addSprite(interface.visual.Line((x,y), (x,n), common.stroke, common.width))
                y = n
                del n
                last = None
            elif command == 'Z': #closepath
                if move == None:
                    raise SyntaxError, "Command 'Z' may not be first command in path"
                instance.addSprite(interface.visual.Line((x,y), move, common.stroke, common.width))
                x = move[0]
                y = move[1]
                move = None
            else:
                raise SyntaxError, "Command named '%s' is unknown for svg path" %command
        return instance
    
    @staticmethod
    def getDefaultAttrs():
        return {'fill':'#000000', 'stroke':'#000000', 'stroke-opacity':'1.0', 'stroke-width':'1', 'fill-opacity':'1.0'} #TODO make sure these defaults are the standards
    
    @staticmethod
    def getCenter(x1, y1, x2, y2, fA, fS, rx, ry, phi):
        """ credits to rikki's answer on http://stackoverflow.com/questions/197649/how-to-calculate-center-of-an-ellipse-by-two-points-and-radius-sizes
        it really helped!
        
        Calculate the centre of the ellipse
        # Based on http://www.w3.org/TR/SVG/implnote.html#ArcConversionEndpointToCenter
        #x1  # Starting x-point of the arc
        #y1  # Starting y-point of the arc
        #x2 # End x-point of the arc
        #y2 # End y-point of the arc
        #fA # Large arc flag
        #fS # Sweep flag
        #rx # Horizontal radius of ellipse
        #ry # Vertical radius of ellipse
        #phi  # Angle between co-ord system and ellipse x-axes
        
        thank you lazyfoo at http://lazyfoo.net/articles/article10/index.php 
        for explaining matrix multiplication enough so I could implement it basically
        """
        
        #Cx = None
        #Cy = None
    
        #Step 1: Compute (x1', y1')
        M = [
                [ math.cos(phi), math.sin(phi)],
                [-math.sin(phi), math.cos(phi)]
            ]
        V = [(x1-x2)/2, (y1-y2)/2]
        P = [M[0][0]*V[0] + M[0][1]*V[1], M[1][0]*V[0] + M[1][1]*V[1]]
        
        x1p = P[0] #x1 prime
        y1p = P[1] #y1 prime
        
        
        #Ensure radii are large enough
        #Based on http://www.w3.org/TR/SVG/implnote.html#ArcOutOfRangeParameters
        #Step (a): Ensure radii are non-zero
        #Step (b): Ensure radii are positive
        rx = abs(rx)
        ry = abs(ry)
        #Step (c): Ensure radii are large enough
        lam = ((x1p * x1p) / (rx * rx) ) + ( (y1p * y1p) / (ry * ry))
        if lam > 1:
            rx = math.sqrt(lam) * rx
            ry = math.sqrt(lam) * ry
        
        
        # Step 2: Compute (cx', cy')
        sign = fA == fS
        if fA == fS:
            sign = -1
        else:
            sign = 1
        # sign = (fA == fS)? -1 : 1;
        
        # Bit of a hack, as presumably rounding errors were making his negative inside the square root! (in javascript) #edit note: not a hack since it works in python
        if((((rx*rx*ry*ry) - (rx*rx*y1p*y1p) - (ry*ry*x1p*x1p) ) / ( (rx*rx*y1p*y1p) + (ry*ry*x1p*x1p))) < 1e-7):
            co = 0
        else:
            co = sign * math.sqrt(((rx*rx*ry*ry) - (rx*rx*y1p*y1p) - (ry*ry*x1p*x1p) ) / ( (rx*rx*y1p*y1p) + (ry*ry*x1p*x1p)))
        V = [rx*y1p/ry, -ry*x1p/rx]
        Cp = [V[0]*co, V[1]*co]
        
        #Step 3: Compute (cx, cy) from (cx', cy')
        M = [
                [ math.cos(phi), -math.sin(phi)],
                [ math.sin(phi),  math.cos(phi)]
            ]
        V = [(x1+x2)/2, (y1+y2)/2]

        C = [M[0][0]*Cp[0] + M[0][1]*Cp[1] + V[0], M[1][0]*Cp[0] + M[1][1]*Cp[1] + V[1]]
        
        Cx = C[0]
        Cy = C[1]
        return (Cx, Cy)
    
    @staticmethod
    def getAngle(cx, cy, x, y):
        return math.degrees(math.atan2((y-cy),(x-cx)))

def parseDist(s):
    """returns s in pixels"""
    try:
        return int(round(float(s)))
    except ValueError:
        pass
    
    if s.endswith('px'):
        return int(round(float(s.strip('px'))))
    else:
        raise TypeError, "Unknown measurement system: %s" %s

SVG_CLASSES = {'$root':SvgRoot, 'svg':SvgRoot, 'g':interface.visual.Team, 'rect':interface.visual.VisualRect, \
               'path':Path, 'text':interface.visual.Text, 'style':Style, 'defs':SvgDefs}