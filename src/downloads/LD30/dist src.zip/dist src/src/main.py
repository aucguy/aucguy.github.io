import zetric
zetric.init()
import menu, misc

zetric.core.Engine.createInstance(misc.SCREEN_SIZE)
engine = zetric.core.Engine.getInstance()
menu.Menu.cacheMenus()
engine.actors.add(zetric.gui.MenuManager(menu.MainMenu.instance))

def main():
    while True:
        engine.getEventQueue().broadcast(misc.EventUpdate())
        engine.handleEvents()
        engine.render((255,255,255))

try:
    main()
except SystemExit:
    engine.quitOnError()