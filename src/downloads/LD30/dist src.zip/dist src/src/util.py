class Grid():
    def __init__(self, size, default=None):
        self.size = size
        self.width, self.height = self.size
        self.contents = []
        for i in xrange(self.width*self.height):
            self.contents.append(default)
    
    def index(self, index):
        return index[1]*self.width + index[0]
    
    def get(self, index):
        return self.contents[self.index(index)]
    
    def set(self, obj, index):
        self.contents[self.index(index)] = obj