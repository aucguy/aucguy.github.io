import zetric, resource, abc, pygame
import misc

class Direction():
    pass

Direction.left = Direction()
Direction.right = Direction()
Direction.up = Direction()
Direction.down = Direction()

class Physical():
    def __init__(self):
        self.rect = None
    
    @abc.abstractmethod
    def pushable(self, entity):
        return False
    
    @abc.abstractmethod
    def move(self, direction, speed):
        pass

class TileWrapper():
    def __init__(self, tile, pos):
        self.tile = tile
        self.rect = zetric.util.Rect((pos[0]*misc.Tile.WIDTH, pos[1]*misc.Tile.HEIGHT), misc.Tile.SIZE)
    
    def pushable(self, entity):
        return False
    
    def move(self, direction, speed):
        raise AssertionError, "cannot move a Tile!"

class Entity(zetric.actor.Actor, Physical):
    def __init__(self, pos, graphic, layer):
        zetric.actor.Actor.__init__(self)
        Physical.__init__(self)
        self.layer = layer
        self.add_handled_queue(self.layer.renderQueue)
        self.add_handled_queue(self.layer.eventQueue)
        root = resource.readSvg('entity/%s.svg' %graphic)
        self.image = zetric.visual.Image((-1, -1), (root.width, root.height))
        root.render(self.image)
        self.image = pygame.transform.scale(self.image, misc.Tile.SIZE)
        self.rect = zetric.util.Rect(pos, misc.Tile.SIZE)
        self.y_vel = 0
        self.handling_physics = False
    
    @zetric.actor.script(misc.EventRenderLayer.ID, 'renderLayer')
    def render(self, event):
        event.image.blit(self.image, (self.rect.left+self.layer.offset[0], self.rect.top+self.layer.offset[1]))
    
    @zetric.actor.script(misc.EventTickGame.ID, zetric.core.MAIN_EVENT_QUEUE_ID)
    def tick(self, event):
        self.y_vel -= 1
        if self.y_vel > 0:
            self.move(Direction.up, self.y_vel)
        elif self.y_vel < 0:
            self.move(Direction.down, abs(self.y_vel))
    
    def genTileWrappers(self, needs_solid = True):
        x_start = self.rect.left/misc.Tile.WIDTH-1
        x_end = x_start+3
        y_start = self.rect.top/misc.Tile.HEIGHT-1
        y_end = y_start+3
        
        for x in xrange(max(0, x_start), min(self.layer.grid.width, x_end)):
            for y in xrange(max(0, y_start), min(self.layer.grid.height, y_end)):
                if not needs_solid or self.layer.grid.get((x,y)).solid:
                    yield TileWrapper(self.layer.grid.get((x,y)), (x,y))
    
    def getLights(self):
        lights = []
        for actor in self.layer.actors:
            if isinstance(actor, Light):
                lights.append(actor)
        return lights
    
    def move(self, direction, speed):        
        assert speed >= 0
        self.handling_physics = True
        
        if speed > 0:
            if direction == Direction.left:
                self.rect.left -= speed
            if direction == Direction.right:
                self.rect.left += speed
            if direction == Direction.up:
                self.rect.top -= speed
            if direction == Direction.down:
                self.rect.top += speed
        
        lights = self.getLights()
        
        for other in self.genTileWrappers():
            if self.rect.colliderect(other):
                self.handle_light_collision(direction, other, lights)
                
        for actor in self.layer.actors:
            if isinstance(actor, Entity) and actor != self and not actor.handling_physics:
                self.handle_collision(direction, actor)
        
        self.handling_physics = False
    
    def handle_light_collision(self, direction, box, lights):
        for light in lights:
            if self.rect.colliderect(light.rect) and box.rect.colliderect(light.rect):
                for rect in self.split_rects(box, light):
                    self.handle_collision(direction, box, rect)
                    return
        self.handle_collision(direction, box)
    
    def split_rects(self, box, light):
        if light.rect.top > box.rect.top:
            yield zetric.util.Rect(box.rect.topleft, (box.rect.width, light.rect.top-box.rect.top))
        if light.rect.bottom < box.rect.bottom:
            yield zetric.util.Rect((box.rect.left, light.rect.bottom), (box.rect.width, box.rect.bottom-light.rect.bottom))
            
        if box.rect.left < light.rect.left: 
            left = box.rect.left
        else:
            left = light.rect.right
        top = max(box.rect.top, light.rect.top)
        if box.rect.left < light.rect.left:
            width = light.rect.left - box.rect.left
        else:
            width = box.rect.right - light.rect.right
        height = min(box.rect.bottom, light.rect.bottom) - top
        yield zetric.util.Rect((left, top), (width, height))
                
    def handle_collision(self, direction, other, rect=None):
        if rect == None:
            rect = other.rect
            
        if self.rect.colliderect(rect):
            if direction == Direction.left:
                if self.rect.left <= rect.right:
                    if other.pushable(self):
                        other.move(direction, rect.right-self.rect.left)
                    self.rect.left = rect.right
            if direction == Direction.right:
                if self.rect.right >= rect.left:
                    if other.pushable(self):
                        other.move(direction, self.rect.right-rect.left)
                    self.rect.right = rect.left
            if direction == Direction.up:
                if self.rect.top <= rect.bottom:
                    self.rect.top = rect.bottom
                    self.y_vel = 0
            if direction == Direction.down:
                if self.rect.bottom >= rect.top:
                    self.rect.bottom = rect.top
                    self.y_vel = 0
    
    def postRead(self):
        pass

class Cube(Entity, misc.LevelClass):
    def __init__(self, pos, graphic, layer):
        Entity.__init__(self, pos, 'box', layer)
        misc.LevelClass.__init__(self)
        self.partner = None
    
    def pushable(self, entity):
        return isinstance(entity, (Player, Box, Source))
    
    def move(self, direction, speed):
        Entity.move(self, direction, speed)
        self.partner.move(direction, speed, True)
    
    def handle_collision(self, direction, other, rect=None):
        if isinstance(other, Light):
            return
        else:
            Entity.handle_collision(self, direction, other, rect)
    
    @abc.abstractmethod
    def createPartner(self):
        pass
    
    def onAdded(self, parent):
        Entity.onAdded(self, parent)
        self.partner = self.createPartner()
        self.layer.opposite.add(self.partner)
    
    def onRemoved(self, parent):
        Entity.onRemoved(self, parent)
        self.partner.layer.remove(self.partner)

class Box(Cube):
    def __init__(self, pos, layer):
        Cube.__init__(self, pos, 'box', layer)
    
    def createPartner(self):
        return Shadow(self)
    
    def handle_collision(self, direction, other, rect=None):
        if isinstance(other, Light):
            return
        else:
            Cube.handle_collision(self, direction, other, rect)
    
    @staticmethod
    def readLevel(element, parser, parent):
        x = int(element.attrs['x'])
        y = int(element.attrs['y'])
        instance = Box((x,y), parent)
        return instance
    
    def writeLevel(self, stream):
        stream.write('<box ')
        stream.write('x="%s" ' %str(self.rect.left))
        stream.write('y="%s"/>' %str(self.rect.top))

class Source(Cube):
    def __init__(self, pos, layer):
        Cube.__init__(self, pos, 'source', layer)
    
    def createPartner(self):
        return Light(self)
    
    def move(self, direction, other):
        self.partner.record_touching()
        Cube.move(self, direction, other)
    
    def handle_collision(self, direction, other):
        if isinstance(other, Shadow):
            return
        else:
            Cube.handle_collision(self, direction, other)
    
    @staticmethod
    def readLevel(element, parser, parent):
        x = int(element.attrs['x'])
        y = int(element.attrs['y'])
        instance = Source((x,y), parent)
        return instance
    
    def writeLevel(self, stream):
        stream.write('<source ')
        stream.write('x="%s" ' %str(self.rect.left))
        stream.write('y="%s"/>' %str(self.rect.top))

class Reflection(Entity):
    def __init__(self, partner, graphic):
        Entity.__init__(self, partner.rect.topleft, graphic, partner.layer.opposite)
        self.partner = partner
        self.rect = self.partner.rect
    
    def pushable(self, entity):
        return False
    
    def move(self, direction, speed, bypartner=False):
        if bypartner:
            Entity.move(self, direction, 0)

class Shadow(Reflection):
    def __init__(self, partner):
        Reflection.__init__(self, partner, 'shadow')
    
    def handle_collision(self, direction, other, rect=None):
        if isinstance(other, (Source, TileWrapper)):
            return
        else:
            Reflection.handle_collision(self, direction, other, rect)

class Light(Reflection):
    def __init__(self, partner):
        Reflection.__init__(self, partner, 'light')
        self.old_rect_topleft = None
        self.touching = None
    
    def record_touching(self):
        self.old_rect_topleft = self.rect.topleft
        self.touching = []
        for actor in self.layer.actors:
            if isinstance(actor, Entity) and not isinstance(actor, Light):
                if self.rect.colliderect(actor.rect):
                    self.touching.append(actor)
    
    def move(self, direction, speed, bypartner=False):
        for entity in self.touching:
            for tile in entity.genTileWrappers():
                for split in entity.split_rects(tile, self):
                    if entity.rect.colliderect(split):
                        self.rect.topleft = self.old_rect_topleft
                        return

class Player(Entity):
    def __init__(self, pos, graphic, layer):
        Entity.__init__(self, pos, graphic, layer)
        self.selected =  self.layer.kind == 1
        self.walk_speed = 5
        self.jump_speed = 12
    
    @zetric.actor.script(zetric.event.EventKeyHeld.getID('a'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def moveLeft(self, event):
        if self.selected:
            self.move(Direction.left, self.walk_speed)
        
    @zetric.actor.script(zetric.event.EventKeyHeld.getID('d'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def moveRight(self, event):
        if self.selected:
            self.move(Direction.right, self.walk_speed)
        
    @zetric.actor.script(zetric.event.EventKeyHeld.getID('w'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def moveUp(self, event):
        if self.selected and self.touching_floor():
            self.y_vel += self.jump_speed
            
    def touching_floor(self):
        if self.touching_something() or self.y_vel > 0:
            return False
        self.rect.top += 1
        if self.touching_something():
            self.rect.top -= 1
            return True
        self.rect.top -= 1
        return False
    
    def touching_something(self):
        for tile in self.genTileWrappers():
            lighted = False
            for light in self.getLights():
                if self.rect.colliderect(light.rect) and tile.rect.colliderect(light.rect):
                    lighted = True
                    for rect in self.split_rects(tile, light):
                        if self.rect.colliderect(rect):
                            return True
            if not lighted and self.rect.colliderect(tile.rect):
                return True
                    
        for actor in self.layer.actors:
            if isinstance(actor, (Box, Shadow, Source)) and actor != self:
                if self.rect.colliderect(actor.rect):
                    return True
        
        return False
    
    def pushable(self, entity):
        return False
    
    def handle_collision(self, direction, other, rect=None):
        if isinstance(other, Light):
            return
        else:
            Entity.handle_collision(self, direction, other, rect)