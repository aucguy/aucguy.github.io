import zetric, resource, level
import misc

class Menu(zetric.html.HtmlRoot):
    def __init__(self, document):
        zetric.html.HtmlRoot.__init__(self)
        self.actors = document.actors
    
    @staticmethod
    def cacheMenus():
        Menu.parser = zetric.html.HtmlParser(zetric.util.Rect((0,0), misc.SCREEN_SIZE), zetric.html.HTML_CLASSES)
        MainMenu.instance = Menu.load(MainMenu, 'main')
        MenuPlay.instance = Menu.load(MenuPlay, 'play')
        MenuLevelSelect.instance = Menu.load(MenuLevelSelect, 'level_select')
        MenuInstruction.instance = Menu.load(MenuInstruction, 'instructions')
    
    @staticmethod
    def load(cl, name):
        Menu.parser.layoutManager.reset()
        root =  zetric.html.HtmlRoot.readHtml(Menu.parser.parse(resource.read('menu/%s.html' %name)), Menu.parser)
        return cl(root)

class MainMenu(Menu):
    instance = None
    def __init__(self, document):
        Menu.__init__(self, document)
        
        @zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
        def playButton(event):
            MenuPlay.instance.setLevel(1)
            zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MenuPlay.instance))
        
        document.getElementById('play').scripts.append(playButton)
        
        @zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
        def levelSelectButton(event):
            zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MenuLevelSelect.instance))
        
        document.getElementById('level select').scripts.append(levelSelectButton)
        
        @zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
        def instructionsButton(event):
            zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MenuInstruction.instance))
        
        document.getElementById('instructions').scripts.append(instructionsButton)
        
class MenuPlay(Menu):
    MAX_LEVEL = 4
    instance = None
    def __init__(self, document):
        Menu.__init__(self, document)
        self.parser = misc.LevelParser(level.LEVEL_CLASSES)
        self.level = None
        self.pause_menu = document.getElementById('pause')
        self.removeActor(self, self.pause_menu)
        
        @zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
        def backButton(event):
            zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MainMenu.instance))
        document.getElementById("back").scripts.append(backButton)
    
    def removeActor(self, group, actor):
        group.remove(actor)
        for i in group.actors:
            if isinstance(i, zetric.actor.Group):
                self.removeActor(i, actor)
    
    def setLevel(self, l):
        if self.level != None:
            self.remove(self.level)
        root = level.LevelRoot.readLevel(self.parser.parse(resource.read('level/%s.xml' %str(l))), self.parser)
        if len(root.actors) != 1 or not isinstance(root.actors[0], level.Level):
            raise SyntaxError, "level file %s ancestor is not of type 'level'" %str(l)
        self.level = root.actors[0]
        self.level.num = l
        self.add(self.level)
    
    @zetric.actor.script(misc.EventUpdate.ID, zetric.core.MAIN_EVENT_QUEUE_ID)
    def update(self, event):
        zetric.core.Engine.getInstance().getEventQueue().broadcast(misc.EventTickGame())
        
    @zetric.actor.script(zetric.event.EventKeyDown.getID('F2'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def changeLevel(self, event):
        level = str(raw_input("Enter level to change to: "))
        self.setLevel(level)
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('escape'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def togglePauseMenu(self, event):
        if self.pause_menu in self.actors:
            self.remove(self.pause_menu)
        else:
            self.add(self.pause_menu)
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('r'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def resetLevel(self, event):
        self.setLevel(self.level.num)

class MenuLevelSelect(Menu):
    instance = None
    def __init__(self, document):
        Menu.__init__(self, document)
        for i in xrange(1, 6):
            exec("""
@zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
def clickLevel(event):
    zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MenuPlay.instance))
    MenuPlay.instance.setLevel(str(%s))
document.getElementById('level %s').scripts.append(clickLevel)""" %(str(i), str(i)))
        
class MenuInstruction(Menu):
    instance = None
    
    def __init__(self, document):
        Menu.__init__(self, document)
        
        @zetric.actor.script(zetric.gui.EventButtonActivate.ID, 'internal')
        def backButton(event):
            zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(MainMenu.instance))
        document.getElementById('back').scripts.append(backButton)