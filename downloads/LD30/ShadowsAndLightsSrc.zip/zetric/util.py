import json, os.path, codecs, pygame

class Rect(pygame.rect.Rect):
	pass

def class_attribute(cl, identifier, top=True):
	print((identifier, str(cl.__dict__), identifier in cl.__dict__))
	if identifier in cl.__dict__:
		return cl.__dict__[identifier]
	else:
		method = None
		for base in cl.__bases__:
			method = class_attribute(base, identifier, False)
		if top and method == None:
			raise AttributeError, "%s has no attribute %s" %(cl.__name__, identifier)
		else:
			return method

def isStaticMethod(obj, identifier):
	return False
	return obj.__getattribute__(identifier) == class_attribute(obj.__class__, identifier)

def iterQueue(queue, limit=None):
	i = 0
	while not queue.empty():
		if limit != None and i > limit:
			break
		yield queue.get()
		i += 1

def iterDict(d):
	for key in d:
		value = d[key]
		yield (key, value)

def xor(a, b):
	return (a and not b) or (not a and b)

def nand(a, b):
	return (a and b) or (not a and not b)

class AttrModResponse(object):
	def __init__(self, parent, onGet, onSet):
		object.__init__(self)
		self.parent = parent
		self.on_get = onGet
		self.on_set = onSet


		def __getattribute__(name):
			self.on_set[name](parent, name)
			return self.parent.__getattribute__(parent, name)

		def __setattr__(name, value):
			self.on_set[name](parent, name, value)
			self.parent.__setattr__(parent, name, value)

		self.__setattr__ = __setattr__
		self.__getattribute__ = __getattribute__

def readFileData(path):
	f = codecs.open(path, encoding='utf-8')
	#r = f.read()[1:]
	r = f.read()
	f.close()
	if r.startswith(u"\ufeff"):
		r = r[1:]
	return r

def loadConf(name):
	return json.loads(readFileData("%s/conf/%s.json" %(os.path.split(__file__)[0], name)))

def loadConfInt(name):
	strings = loadConf(name)
	ints = {}
	for key, value in iterDict(strings):
		ints[int(key)] = value
	return ints

def convertAttrs(attrs):
	r = {}
	for key, value in attrs:
		r[key] = value
		
class Stack():
	def __init__(self):
		self.contents = []
	
	def push(self, obj):
		self.contents.append(obj)
		
	def pop(self):
		return self.contents.pop()
	
	def peek(self):
		return self.contents[len(self.contents)-1]

def asInt(i):
	return eval("int(%s)" %i)

def unzip(zipped):
	r = []
	for i in xrange(len(zipped[0])):
		r.append([])
		
	for i in zipped:
		for k, j in enumerate(i):
			r[k].append(j)
	return r

def joinDict(a, b):
	r = {}
	for key, value in iterDict(b):
		r[key] = value
	
	for key, value in iterDict(a):
		r[key] = value
	
	return r

def joinLists(*a):
	n = []
	for i in a:
		n.extend(i)
	return n