import __init__ as interface

def init():
	pass

def script(event, queue):
	if not isinstance(event, int):
		raise TypeError, "event id must be an ID(int), but it's %s" %event
	def decorator(function):
		if 'decorators' not in dir(function):
			function.decorators = {}
		function.decorators['script'] = {'event.ID': event, 'queue.ID': queue}
		return function
	return decorator

class Actor(object):
	def __init__(self):
		self.scripts = []
		self.handled_queues = {}
		self.event_queue = interface.event.EventQueue('internal')
		self.render_queue = interface.event.EventQueue('internal_render')
		self.add_handled_queue(self.event_queue)
		self.add_handled_queue(self.render_queue)
		self.add_handled_queue(interface.event.EventQueue.getQueue(interface.core.MAIN_EVENT_QUEUE_ID))
		self.add_handled_queue(interface.event.EventQueue.getQueue(interface.core.MAIN_RENDER_QUEUE_ID))

	def get_handled_queues(self):
		return self.handled_queues
	
	def add_handled_queue(self, queue):
		if queue.ID not in self.handled_queues:
			self.handled_queues[queue.ID] = queue

	def remove_handled_queue(self, queue):
		if queue.ID in self.handled_queues:
			del self.handled_queues[queue.ID]
	
	def onAdded(self, parent):
		self.hook_scripts(self.get_handled_queues())
	
	def onRemoved(self, parent):
		self.unhook_scripts(self.get_handled_queues())
	
	def hook_scripts(self, queues):
		for identifier in dir(self):
			value = eval('self.%s' %identifier)
			if 'decorators' in dir(value) and 'script' in value.decorators and not interface.util.isStaticMethod(self, identifier):
				self.scripts.append(value)

		for script in self.scripts:
			event_ID = script.decorators['script']['event.ID']
			queue_ID = script.decorators['script']['queue.ID']
			event_queue = queues[queue_ID]
			event_queue.addScript(event_ID, script)
	
	def unhook_scripts(self, queues):
		for script in self.scripts:
			event_ID = script.decorators['script']['event.ID']
			queue_ID = script.decorators['script']['queue.ID']
			event_queue = queues[queue_ID]
			event_queue.removeScript(event_ID, script)

class Group(Actor, interface.xml.HtmlClass):
	def __init__(self, actors=None):
		Actor.__init__(self)
		if actors == None:
			self.actors = []
		else:
			self.actors = actors
		self.added = False
	
	def add(self, *actors):
		for actor in actors:
			if actor not in self.actors:
				self.actors.append(actor) #this adds self to actor.actors
				if self.added:
					actor.onAdded(self)

	def remove(self, *actors):
		for actor in actors:
			if actor in self.actors:
				self.actors.remove(actor)
				if self.added:
					actor.onRemoved(self)
	
	def onAdded(self, parent):
		Actor.onAdded(self, parent)
		self.added = True
		for actor in self.actors:
			actor.onAdded(self)

	def onRemoved(self, parent):
		Actor.onRemoved(self, parent)
		self.added = False
		for actor in self.actors:
			actor.onRemoved(self)
	
	def __contains__(self, item):
		return False
		for i in self.actors:
			if i == item:
				return True
			elif isinstance(i, Group):
				if item in i:
					return True
		return False

	def __iter__(self):
		for i in self.actors:
			yield i
			
	@staticmethod
	def readHtml(element, parser):
		interface.xml.HtmlClass.readHtml(element, parser)
		instance = Group()
		interface.xml.HtmlClass.htmlInit(instance, element, parser)
		
		for child in element.children:
			if parser.hasClass(child.name):
				instance.add(parser.getClass(child.name).readHtml(child, parser))
		return instance