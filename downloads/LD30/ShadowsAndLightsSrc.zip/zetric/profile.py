import time

class Profiler(object):
    the_instance = None
    
    @staticmethod
    def getInstance():
        if Profiler.the_instance == None:
            the_instance = Profiler()
        return the_instance
    
    def message(self, level, message):
        print("[%s][%s]:\t %s" %(time.ctime(), level, message))
    
    def debug(self, message):
        print(self.message("debug", message))
    
    def info(self, message):
        print(self.message("info", message))
        
    def warning(self, message):
        print(self.message("warning", message))
        
    def error(self, message):
        print(self.message("error", message))
        
    def variables(self, var):
        s = ""
        for key in var:
            value = vars[key]
            s += "%s = %s, " %(key, value)
        s = s.rstrip(",")
        self.message("vars", s)
    
def time_duration(func):
    """this is a decorator! Times how long a function runs for"""
    def make(*args, **kargs):
        start = time.time()
        func(*args, **kargs)
        Profiler.getInstance().info(time.time()-start)
    return make