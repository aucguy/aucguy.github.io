import pygame, zetric, menu, util, resource, entity
import misc

EDIT_MODE = False

class LevelRoot(zetric.actor.Group, misc.LevelClass):
    @staticmethod
    def readLevel(element, parser):
        misc.LevelClass.readLevel(element, parser, None)
        instance = LevelRoot()
        misc.LevelClass.levelInit(instance, element, parser)
        for child in element.children:
            if parser.hasClass(child.name):
                instance.add(parser.getClass(child.name).readLevel(child, parser, instance))
        return instance

class Mode():
    def __init__(self, editable, layer):
        self.editable = editable
        self.layer = layer

Mode.PLAY = Mode(False, None)
Mode.LAYER1 = Mode(True, 1)
Mode.LAYER2 = Mode(True, 2)

class Level(zetric.actor.Group, misc.LevelClass):
    def __init__(self):
        zetric.actor.Group.__init__(self)
        misc.LevelClass.__init__(self)
        self.mode = Mode.PLAY
        self.layer1 = None
        self.layer2 = None
        self.pick = misc.Tile.filled
        self.num = None
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('space'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def toggleSelectedPlayer(self, event):
        if self.layer1.player.selected:
            self.layer1.player.selected = False
            self.layer2.player.selected = True
        else:
            self.layer1.player.selected = True
            self.layer2.player.selected = False
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('1'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def changePickEmpty(self, event):
        if self.mode.editable:
            self.pick = misc.Tile.empty
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('2'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def changePickFilled(self, event):
        if self.mode.editable:
            self.pick = misc.Tile.filled
            
    @zetric.actor.script(zetric.event.EventKeyDown.getID('3'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def changePickSpawn(self, event):
        if self.mode.editable:
            self.pick = misc.Tile.spawn
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('4'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def changePickExit(self, event):
        if self.mode.editable:
            self.pick = misc.Tile.exit
    
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('comma'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def spawnBox(self, event):
        self.spawnCube(entity.Box)
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('slash'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def spawnSource(self, event):
        self.spawnCube(entity.Source)
    
    def spawnCube(self, cl):
        if self.mode.editable:
            layer = self.getSelectedLayer()
            rect = zetric.util.Rect((-1,-1), (misc.Tile.WIDTH, misc.Tile.HEIGHT))
            pos = pygame.mouse.get_pos()
            rect.center = (pos[0]-layer.offset[0], pos[1]-layer.offset[1])
            
            if rect.left < 0 or rect.right > layer.background.get_width() or rect.top < 0 or rect.bottom > layer.background.get_height():
                return
            
            for actor in layer.actors:
                if isinstance(actor, entity.Entity):
                    if rect.colliderect(actor.rect):
                        return
            
            layer.add(cl(rect.topleft, layer))
            
    @zetric.actor.script(zetric.event.EventKeyDown.getID('period'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def despawnCube(self, event):
        if self.mode.editable:
            layer = self.getSelectedLayer()
            pos = pygame.mouse.get_pos()
            pos = (pos[0]-layer.offset[0], pos[1]-layer.offset[1])
            for actor in layer.actors:
                if isinstance(actor, (entity.Cube)) and actor.rect.collidepoint(pos):
                    layer.remove(actor)
    
    @zetric.actor.script(zetric.visual.EventRenderScreen.ID, zetric.core.MAIN_RENDER_QUEUE_ID)
    def render(self, event):
        self.layer1.renderQueue.broadcast(misc.EventRenderLayer(event.image))
        self.layer2.renderQueue.broadcast(misc.EventRenderLayer(event.image))
    
    #@zetric.actor.script(zetric.visual.EventRenderScreen.ID, zetric.core.MAIN_RENDER_QUEUE_ID)
    def renderOld(self, event):
        #background = None
        
        event.image.blit(self.layer2.background, self.layer2.offset)
        
        blue = zetric.visual.Image(self.layer2.offset, self.layer2.background.get_rect().size)
        blue.fill((0,0,255,128))
        event.image.blit(blue, self.layer2.offset)
        del blue
        
        back = pygame.surface.Surface(event.image.get_rect().size, pygame.SRCALPHA)
        back.blit(event.image, (0,0))
        sur = pygame.surface.Surface(self.layer1.background.get_rect().size)
        sur.fill((0,1,0))
        sur.blit(self.layer1.background, (0,0))
        sur.set_colorkey((0,1,0))
        sur.set_alpha(128)
        back.blit(sur, self.layer1.offset)
        event.image.blit(back, (0,0))
        del back, sur
        
        red = zetric.visual.Image(self.layer1.offset, self.layer1.background.get_rect().size)
        red.fill((255,0,0,128))
        event.image.blit(red, self.layer1.offset)
        del red        
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('BACKQUOTE'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def toggleMode(self, event):
        if EDIT_MODE:
            if self.mode == Mode.PLAY:
                self.mode = Mode.LAYER1
                new = 'layer1'
            elif self.mode == Mode.LAYER1:
                self.mode = Mode.LAYER2
                new = 'layer2'
            else:
                self.mode = Mode.PLAY
                new = 'play'
            print("Mode changed to %s" %new)
    
    @zetric.actor.script(zetric.event.EventMouseHeld.ID_LEFT, zetric.core.MAIN_EVENT_QUEUE_ID)
    def setTile(self, event):
        if self.mode.editable:
            layer = self.getSelectedLayer()
            tile_x = (event.pos[0]-layer.offset[0])/misc.Tile.WIDTH
            tile_y = (event.pos[1]-layer.offset[1])/misc.Tile.HEIGHT
            
            if 0 <= tile_x < layer.grid.width and  0 <= tile_y < layer.grid.height:
                layer.grid.set(self.pick, (tile_x, tile_y))
                layer.renderBackground()
    
    def getSelectedLayer(self):
        if self.mode.layer == 1:
            return self.layer1
        elif self.mode.layer == 2:
            return self.layer2
        else:
            return None
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('F1'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def saveLevel(self, event):
        if self.mode.editable:
            name = raw_input('Enter location to save the level: ')
            f = resource.getFile('level/%s.xml' %name, 'w')
            self.writeLevel(f)
            f.close()
    
    @zetric.actor.script(zetric.event.EventKeyDown.getID('return'), zetric.core.MAIN_EVENT_QUEUE_ID)
    def endLevel(self, event):
        if self.player_at_exit(self.layer1.player) and self.player_at_exit(self.layer2.player):
            if self.num >= menu.MenuPlay.MAX_LEVEL:
                zetric.core.Engine.getInstance().getEventQueue().broadcast(zetric.gui.EventMenuChange(menu.MainMenu.instance))
            else:
                menu.MenuPlay.instance.setLevel(self.num + 1)
        
    def player_at_exit(self, player):
        for wrapper in player.genTileWrappers(False):
            if wrapper.tile == misc.Tile.exit:
                return True
        return False
    
    def postRead(self):
        self.layer1.opposite = self.layer2
        self.layer2.opposite = self.layer1
        self.layer1.postRead()
        self.layer2.postRead()
    
    @staticmethod
    def readLevel(element, parser, parent):
        misc.LevelClass.readLevel(element, parser)
        
        instance = Level()
        misc.LevelClass.levelInit(instance, element, parser)
        for child in element.children:
            if parser.hasClass(child.name):
                instance.add(parser.getClass(child.name).readLevel(child, parser, instance))
        
        for actor in instance.actors:
            if isinstance(actor, Layer):
                actor.grid.width = int(element.attrs['width'])
                actor.grid.height = int(element.attrs['height'])
                actor.grid.size = (actor.grid.width, actor.grid.height)
                actor.renderBackground()
                if actor.color == Layer.COLOR1:
                    instance.layer1 = actor
                elif actor.color == Layer.COLOR2:
                    instance.layer2 = actor
                else:
                    raise SyntaxError, "unknown layer color"
        instance.postRead()
        return instance
    
    def writeLevel(self, stream):
        stream.write('<level ')
        stream.write('width="%s" ' %str(self.layer1.grid.width))
        stream.write('height="%s">' %str(self.layer1.grid.height))
        
        for actor in self.actors:
            if isinstance(actor, misc.LevelClass):
                actor.writeLevel(stream)
                
        stream.write("</level>")

class Layer(zetric.actor.Group, misc.LevelClass):
    COLOR1 = (255,0,0)
    COLOR2 = (0,0,255)
    def __init__(self, grid, kind):
        zetric.actor.Group.__init__(self)
        misc.LevelClass.__init__(self)
        self.grid = grid
        if kind == 'red':
            self.kind = 1
            self.color = Layer.COLOR1
            self.offset = (600,0)
        elif kind == 'blue':
            self.kind = 2
            self.color = Layer.COLOR2
            self.offset = (0,0)
        else:
            raise SyntaxError, "unknown layer color"
        self.renderQueue = zetric.event.EventQueue('renderLayer', [zetric.core.MAIN_RENDER_QUEUE_ID], zetric.core.renderStream)
        self.eventQueue = zetric.event.EventQueue('eventLayer', [zetric.core.MAIN_EVENT_QUEUE_ID])
        self.add_handled_queue(self.renderQueue)
        self.add_handled_queue(self.eventQueue)
        self.opposite = None
    
    @zetric.actor.script(misc.EventRenderLayer.ID, 'renderLayer')
    def render(self, event):
        back = zetric.visual.Image(self.offset, self.background.get_rect().size)
        l = list(self.color)
        l.append(128)
        back.fill(l)
        event.image.blit(back, self.offset)
        event.image.blit(self.background, self.offset)
    
    def renderBackground(self):
        self.background = zetric.visual.Image((0,0), (self.grid.width*misc.Tile.WIDTH, self.grid.height*misc.Tile.HEIGHT))
        tiles = iter(self.grid.contents)
        for y in xrange(self.grid.height):
            render_y = y*misc.Tile.HEIGHT
            for x in xrange(self.grid.width):
                render_x = x*misc.Tile.WIDTH
                image = tiles.next().image
                self.background.blit(image, (render_x, render_y))
    
    def postRead(self):
        for x in xrange(self.grid.width):
            for y in xrange(self.grid.height):
                if self.grid.get((x,y)) == misc.Tile.spawn:
                    self.player = entity.Player((x*misc.Tile.WIDTH, y*misc.Tile.HEIGHT), 'player_red', self)
                    self.add(self.player)
                    
        for actor in self.actors:
            if isinstance(actor, entity.Entity):
                actor.postRead()
    
    @staticmethod
    def readLevel(element, parser, parent):
        misc.LevelClass.readLevel(element, parser)
        
        contents = []
        for i in element.attrs['tiles']:
            contents.append(misc.Tile.TILES[ord(i)])
        grid = util.Grid((-1, -1)) #size is an attribute of the parent ('level')
        grid.contents = contents
        
        instance = Layer(grid, element.attrs['type'])
        misc.LevelClass.levelInit(instance, element, parser)
        for child in element.children:
            if parser.hasClass(child.name):
                instance.add(parser.getClass(child.name).readLevel(child, parser, instance))
        return instance
    
    def writeLevel(self, stream):
        stream.write('<layer ')
        if self.kind == 1:
            kind = 'red'
        elif self.kind == 2:
            kind = 'blue'
        else:
            raise AssertionError, "impossible kind"
        stream.write('type="%s" ' %kind)
        stream.write('tiles="')
        for tile in self.grid.contents:
            c = chr(tile.ID)
            if c == '"':
                stream.write('\\')
            stream.write(c)
        stream.write('">')
        stream.flush()
        
        for actor in self.actors:
            if isinstance(actor, misc.LevelClass):
                actor.writeLevel(stream)
        stream.write("</layer>")

LEVEL_CLASSES = {'$root': LevelRoot, 'level': Level, 'layer': Layer, 'box': entity.Box, 'source':entity.Source}